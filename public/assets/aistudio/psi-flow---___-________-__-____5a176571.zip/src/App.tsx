import React, { useState, useEffect, useMemo } from 'react';
import { ProductItem, PsiDataStore, ViewMode, DailyHubRecord, MonthlyInitialStockRecord } from './types/psi';
import {
  INITIAL_PRODUCTS,
  generateDateRange,
  generateDateRangeFromStart,
  generateInitialRecords,
  ensureDatesInDataStore,
  exportToCsv,
  downloadFile,
  forwardFillModelField,
  batchForwardFillPlans,
  ensureProductModels,
} from './utils/psiEngine';
import { parseShareableUrl } from './utils/shareUtils';
import {
  WeekInfo,
  getISOWeekInfo,
  generateWeeklyOptions,
  parseWeeklyShareUrl,
} from './utils/weeklyUtils';
import {
  initAuth,
  googleSignIn,
  OWNER_EMAIL,
} from './services/googleAuth';
import { TopBar } from './components/TopBar';
import { FilterToolbar } from './components/FilterToolbar';
import { MatrixGrid } from './components/MatrixGrid';
import { TrendAnalytics } from './components/TrendAnalytics';
import { ProductMasterView } from './components/ProductMasterView';
import { ProductModal } from './components/ProductModal';
import { CsvImportModal } from './components/CsvImportModal';
import { ShareModal } from './components/ShareModal';
import { WeeklyShareModal } from './components/WeeklyShareModal';
import { GoogleSheetsSyncModal } from './components/GoogleSheetsSyncModal';
import { ForwardFillModal } from './components/ForwardFillModal';
import { LineCapaModal } from './components/LineCapaModal';
import { AccessLogModal } from './components/AccessLogModal';
import { recordAccessLogSilently } from './services/accessLogService';
import { CheckCircle2, Info, RotateCcw } from 'lucide-react';

const STORAGE_KEY_PRODUCTS = 'psi_flow_products_v3';
const STORAGE_KEY_DATA = 'psi_flow_datastore_v3';

export default function App() {
  // Navigation Tab
  const [currentTab, setCurrentTab] = useState<'matrix' | 'analytics' | 'products'>('matrix');

  // Start Date for Date Navigation (과거/미래 자유 이동 지원)
  const getInitialStartDate = () => {
    const d = new Date();
    d.setDate(d.getDate() - 2);
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  };
  const [startDateStr, setStartDateStr] = useState<string>(getInitialStartDate);

  // Days Range (7, 14, 30 days)
  const [daysRange, setDaysRange] = useState<number>(14);
  const dateList = useMemo(
    () => generateDateRangeFromStart(startDateStr, daysRange),
    [startDateStr, daysRange]
  );

  // Check URL Weekly Snapshot on Initial Load
  const initialWeeklySnapshot = useMemo(() => parseWeeklyShareUrl(), []);
  const initialUrlSnapshot = useMemo(() => parseShareableUrl(), []);

  // Ownership & Permission State
  const [currentUserEmail, setCurrentUserEmail] = useState<string | null>(null);
  const [isOwner, setIsOwner] = useState<boolean>(() => {
    if (initialWeeklySnapshot) return false; // Recipients are read-only
    return true; // Author working in studio
  });

  // Current Working Week
  const [currentWeek, setCurrentWeek] = useState<WeekInfo>(() => {
    if (initialWeeklySnapshot) {
      return {
        weekId: initialWeeklySnapshot.weekId,
        weekLabel: initialWeeklySnapshot.weekLabel,
        year: 2026,
        weekNumber: parseInt(initialWeeklySnapshot.weekId.split('-W')[1] || '43', 10) || 43,
        startDateStr: '2026-10-19',
        endDateStr: '2026-10-25',
      };
    }
    return getISOWeekInfo();
  });
  const availableWeeks = useMemo(() => generateWeeklyOptions(), []);

  // Products State with localStorage fallback and auto migration
  const [products, setProducts] = useState<ProductItem[]>(() => {
    if (initialWeeklySnapshot?.products && initialWeeklySnapshot.products.length > 0) {
      return initialWeeklySnapshot.products.map((p, idx) => ensureProductModels(p, idx));
    }
    if (initialUrlSnapshot?.products && initialUrlSnapshot.products.length > 0) {
      return initialUrlSnapshot.products.map((p, idx) => ensureProductModels(p, idx));
    }
    try {
      const saved = localStorage.getItem(STORAGE_KEY_PRODUCTS);
      if (saved) {
        const parsed: ProductItem[] = JSON.parse(saved);
        return parsed.map((p, idx) => ensureProductModels(p, idx));
      }
    } catch {
      // ignore
    }
    return INITIAL_PRODUCTS;
  });

  // Daily Records Store with localStorage fallback
  const [dataStore, setDataStore] = useState<PsiDataStore>(() => {
    if (initialWeeklySnapshot?.dataStore) {
      return initialWeeklySnapshot.dataStore;
    }
    if (initialUrlSnapshot?.dataStore) {
      return initialUrlSnapshot.dataStore;
    }
    try {
      const saved = localStorage.getItem(STORAGE_KEY_DATA);
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return generateInitialRecords(INITIAL_PRODUCTS, generateDateRange(14, 2));
  });

  // Filter & Search States (4대 핵심 드릴다운 필터: 품목, 카테고리, 차종, 거점)
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedProductId, setSelectedProductId] = useState('ALL');
  const [selectedCategory, setSelectedCategory] = useState('ALL');
  const [selectedVehicleModel, setSelectedVehicleModel] = useState('ALL');
  const [selectedHub, setSelectedHub] = useState('ALL');
  const [viewMode, setViewMode] = useState<ViewMode>('all');
  const [allocationMode, setAllocationMode] = useState<'pallet' | 'exact'>('pallet');

  // Accordion Expand States
  const [expandedProductIds, setExpandedProductIds] = useState<Record<string, boolean>>(() => {
    const map: Record<string, boolean> = {};
    INITIAL_PRODUCTS.forEach((p) => {
      map[p.id] = true;
    });
    return map;
  });
  const [allExpanded, setAllExpanded] = useState<boolean>(true);

  // Modals
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);
  const [productToEdit, setProductToEdit] = useState<ProductItem | null>(null);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [isResetConfirmOpen, setIsResetConfirmOpen] = useState(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [isWeeklyShareModalOpen, setIsWeeklyShareModalOpen] = useState(false);
  const [isGoogleSyncModalOpen, setIsGoogleSyncModalOpen] = useState(false);
  const [isForwardFillModalOpen, setIsForwardFillModalOpen] = useState(false);
  const [forwardFillProductId, setForwardFillProductId] = useState<string>('ALL');
  const [isLineCapaModalOpen, setIsLineCapaModalOpen] = useState(false);
  const [isAccessLogModalOpen, setIsAccessLogModalOpen] = useState(false);

  // Toast Notification
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3000);
  };

  // Mount effect: Listen to Auth state and load snapshot notice
  useEffect(() => {
    const unsubscribe = initAuth(
      (user, _token, isOwnerResult) => {
        setCurrentUserEmail(user.email || null);
        setIsOwner(isOwnerResult);
      },
      () => {
        // Not signed in
      }
    );

    if (initialWeeklySnapshot) {
      showToast(
        `🔒 [${initialWeeklySnapshot.weekId}] 주차별 확정 계획을 읽기 전용 모드로 불러왔습니다.`
      );
      recordAccessLogSilently(initialWeeklySnapshot.weekId, initialWeeklySnapshot.weekLabel, false);
    } else if (initialUrlSnapshot) {
      showToast('🔗 공유 링크로부터 작업 스냅샷을 불러왔습니다.');
      recordAccessLogSilently(currentWeek.weekId, currentWeek.weekLabel, false);
    } else {
      recordAccessLogSilently(currentWeek.weekId, currentWeek.weekLabel, isOwner);
    }

    return () => unsubscribe();
  }, [initialWeeklySnapshot, initialUrlSnapshot]);

  // Sync to localStorage if in edit mode
  useEffect(() => {
    if (isOwner) {
      try {
        localStorage.setItem(STORAGE_KEY_PRODUCTS, JSON.stringify(products));
      } catch {
        // ignore
      }
    }
  }, [products, isOwner]);

  useEffect(() => {
    if (isOwner) {
      try {
        localStorage.setItem(STORAGE_KEY_DATA, JSON.stringify(dataStore));
      } catch {
        // ignore
      }
    }
  }, [dataStore, isOwner]);

  // Week Navigation Handlers
  const handlePrevWeek = () => {
    const idx = availableWeeks.findIndex((w) => w.weekId === currentWeek.weekId);
    if (idx > 0) {
      const targetWeek = availableWeeks[idx - 1];
      setCurrentWeek(targetWeek);
      setStartDateStr(targetWeek.startDateStr);
    } else {
      const d = new Date(currentWeek.startDateStr);
      d.setDate(d.getDate() - 7);
      const targetWeek = getISOWeekInfo(d);
      setCurrentWeek(targetWeek);
      setStartDateStr(targetWeek.startDateStr);
    }
  };

  const handleNextWeek = () => {
    const idx = availableWeeks.findIndex((w) => w.weekId === currentWeek.weekId);
    if (idx >= 0 && idx < availableWeeks.length - 1) {
      const targetWeek = availableWeeks[idx + 1];
      setCurrentWeek(targetWeek);
      setStartDateStr(targetWeek.startDateStr);
    } else {
      const d = new Date(currentWeek.startDateStr);
      d.setDate(d.getDate() + 7);
      const targetWeek = getISOWeekInfo(d);
      setCurrentWeek(targetWeek);
      setStartDateStr(targetWeek.startDateStr);
    }
  };

  // Timeline Navigation Handlers (과거/미래 자유 이동)
  const handlePrevPeriod = () => {
    const [y, m, d] = startDateStr.split('-').map(Number);
    const dateObj = new Date(y, m - 1, d);
    dateObj.setDate(dateObj.getDate() - (daysRange === 7 ? 7 : daysRange === 14 ? 7 : 14));
    const nextStr = `${dateObj.getFullYear()}-${String(dateObj.getMonth() + 1).padStart(2, '0')}-${String(dateObj.getDate()).padStart(2, '0')}`;
    setStartDateStr(nextStr);
  };

  const handleNextPeriod = () => {
    const [y, m, d] = startDateStr.split('-').map(Number);
    const dateObj = new Date(y, m - 1, d);
    dateObj.setDate(dateObj.getDate() + (daysRange === 7 ? 7 : daysRange === 14 ? 7 : 14));
    const nextStr = `${dateObj.getFullYear()}-${String(dateObj.getMonth() + 1).padStart(2, '0')}-${String(dateObj.getDate()).padStart(2, '0')}`;
    setStartDateStr(nextStr);
  };

  const handleJumpToday = () => {
    setStartDateStr(getInitialStartDate());
  };

  const handleStartDateChange = (val: string) => {
    if (val) setStartDateStr(val);
  };

  // 날짜 범위가 과거/미래로 확장되었을 때, 신규 날짜에 대한 기본 PSI 레코드를 자동 보완
  useEffect(() => {
    setDataStore((prevStore) => ensureDatesInDataStore(prevStore, products, dateList));
  }, [dateList, products]);

  // In-cell Forward Fill Handler
  const handleForwardFillField = (
    productId: string,
    modelId: string | null,
    field: 'prodPlan' | 'prodActual' | 'salesPlan' | 'salesActual' | 'inboundPlan' | 'inboundActual',
    fromDateStr: string,
    value: number,
    keepWeekendZero: boolean
  ) => {
    if (!isOwner) return;
    setDataStore((prev) =>
      forwardFillModelField(prev, productId, modelId, field, fromDateStr, value, keepWeekendZero, dateList)
    );
    showToast(`기준일 [${fromDateStr}] 이후 날짜로 값이 일괄 전개되었습니다.`);
  };

  // Batch Forward Fill Plans Handler (Modal)
  const handleBatchForwardFillPlans = (params: {
    productIds: string[];
    startDateStr: string;
    prodPlan: number;
    modelPlans: Record<string, number>;
    syncInbound: boolean;
    keepWeekendZero: boolean;
  }) => {
    if (!isOwner) return;
    setDataStore((prev) => batchForwardFillPlans(prev, products, { ...params, dateList }));
    showToast('⚡ 오늘 기준 생산·차종별 소요량 계획이 성공적으로 일괄 전개되었습니다!');
  };

  // Import Workspace Handler
  const handleImportWorkspace = (importedProds: ProductItem[], importedStore: PsiDataStore) => {
    if (!isOwner) return;
    const sanitized = importedProds.map((p, idx) => ensureProductModels(p, idx));
    setProducts(sanitized);
    setDataStore(importedStore);
    const expMap: Record<string, boolean> = {};
    sanitized.forEach((p) => {
      expMap[p.id] = true;
    });
    setExpandedProductIds(expMap);
  };

  // Categories list
  const categories = useMemo(() => {
    const set = new Set(products.map((p) => p.category).filter(Boolean));
    return Array.from(set);
  }, [products]);

  // Vehicle Models list
  const vehicleModels = useMemo(() => {
    const set = new Set<string>();
    products.forEach((p) => {
      p.models.forEach((m) => {
        if (m.name) set.add(m.name);
      });
    });
    return Array.from(set);
  }, [products]);

  // Hubs list from all product models (출고센터: 울산, 광주, 화성, 아산 등)
  const hubs = useMemo(() => {
    const set = new Set<string>();
    products.forEach((p) => {
      p.models.forEach((m) => {
        if (m.hubName) set.add(m.hubName);
      });
    });
    return Array.from(set);
  }, [products]);

  // Filtered Products (4대 핵심 드릴다운 필터: 품목, 카테고리, 차종, 거점 연동)
  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      const q = searchQuery.toLowerCase();
      const matchQuery =
        p.code.toLowerCase().includes(q) ||
        p.name.toLowerCase().includes(q) ||
        p.models.some(
          (m) =>
            m.name.toLowerCase().includes(q) ||
            m.customer.toLowerCase().includes(q) ||
            m.hubName.toLowerCase().includes(q)
        );
      const matchProduct = selectedProductId === 'ALL' || p.id === selectedProductId;
      const matchCategory = selectedCategory === 'ALL' || p.category === selectedCategory;
      const matchVehicle =
        selectedVehicleModel === 'ALL' || p.models.some((m) => m.name === selectedVehicleModel);
      const matchHub =
        selectedHub === 'ALL' || p.models.some((m) => (m.hubName || '울산 출고센터') === selectedHub);

      return matchQuery && matchProduct && matchCategory && matchVehicle && matchHub;
    });
  }, [products, searchQuery, selectedProductId, selectedCategory, selectedVehicleModel, selectedHub]);

  // Cell Change Handler (Protected by isOwner)
  const handleCellChange = (
    productId: string,
    modelId: string | null,
    dateStr: string,
    field: 'prodPlan' | 'prodActual' | 'salesPlan' | 'salesActual' | 'inboundPlan' | 'inboundActual',
    value: number
  ) => {
    if (!isOwner) return;
    setDataStore((prev) => {
      const prodStore = prev[productId] || {};
      const currentDay = prodStore[dateStr] || {
        prodPlan: 0,
        prodActual: 0,
        models: {},
      };
      if (!currentDay.models) currentDay.models = {};

      const updatedDay: DailyHubRecord = { ...currentDay };
      const modelsMap = currentDay.models ? { ...currentDay.models } : {};

      if (!modelId) {
        if (field === 'prodPlan' || field === 'prodActual') {
          updatedDay[field] = value;
        }
      } else {
        const prod = products.find((p) => p.id === productId);
        const targetModel = prod?.models.find((m) => m.id === modelId);

        // 입고계획 및 입고실적은 해당 거점(출고센터) 단위로 관리
        if (targetModel && (field === 'inboundPlan' || field === 'inboundActual')) {
          const siblingModels = prod?.models.filter((m) => m.hubName === targetModel.hubName) || [];
          siblingModels.forEach((sm) => {
            const curSm = modelsMap[sm.id] || {
              inboundPlan: 0,
              inboundActual: 0,
              salesPlan: 0,
              salesActual: 0,
            };
            modelsMap[sm.id] = {
              ...curSm,
              [field]: sm.id === targetModel.id ? value : 0,
            };
          });

          // 거점 단위 직렬화 동기화
          const hubKey = targetModel.hubName || '울산 출고센터';
          const existingHubs = updatedDay.hubs ? { ...updatedDay.hubs } : {};
          const curHubMetric = existingHubs[hubKey] || { inboundPlan: 0, inboundActual: 0 };
          existingHubs[hubKey] = {
            ...curHubMetric,
            [field]: value,
          };
          updatedDay.hubs = existingHubs;
        } else {
          const curModel = modelsMap[modelId] || {
            inboundPlan: 0,
            inboundActual: 0,
            salesPlan: 0,
            salesActual: 0,
          };
          modelsMap[modelId] = {
            ...curModel,
            [field]: value,
          };
        }
        updatedDay.models = modelsMap;
      }

      return {
        ...prev,
        [productId]: {
          ...prodStore,
          [dateStr]: updatedDay,
        },
      };
    });
  };

  // Toggle Single Product Accordion
  const handleToggleProductExpand = (id: string) => {
    setExpandedProductIds((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  // Toggle All Expand / Collapse
  const handleToggleExpandAll = () => {
    const nextState = !allExpanded;
    setAllExpanded(nextState);
    const updated: Record<string, boolean> = {};
    products.forEach((p) => {
      updated[p.id] = nextState;
    });
    setExpandedProductIds(updated);
  };

  // Export CSV
  const handleExportCsv = () => {
    const csvData = exportToCsv(filteredProducts, dateList, dataStore);
    const dateStamp = new Date().toISOString().slice(0, 10);
    downloadFile(csvData, `PSI_Flow_Report_${currentWeek.weekId}_${dateStamp}.csv`);
    showToast(`[${currentWeek.weekId}] 엑셀(CSV) 보고서가 성공적으로 다운로드되었습니다.`);
  };

  // Save / Update Product
  const handleSaveProduct = (product: ProductItem) => {
    if (!isOwner) return;
    const sanitized = ensureProductModels(product);
    setProducts((prev) => {
      const idx = prev.findIndex((p) => p.id === sanitized.id);
      if (idx >= 0) {
        const copy = [...prev];
        copy[idx] = sanitized;
        return copy;
      }
      return [...prev, sanitized];
    });

    setDataStore((prev) => {
      if (!prev[sanitized.id]) {
        const newProdMap: Record<string, DailyHubRecord> = {};
        dateList.forEach((d) => {
          const modelsMap: Record<string, any> = {};
          sanitized.models.forEach((m, idx) => {
            modelsMap[m.id] = {
              inboundPlan: idx === 0 ? 2500 : idx === 1 ? 500 : 1200,
              inboundActual: 0,
              salesPlan: idx === 0 ? 2500 : idx === 1 ? 500 : 1200,
              salesActual: 0,
            };
          });
          newProdMap[d] = {
            prodPlan: 8000,
            prodActual: 0,
            models: modelsMap,
          };
        });
        return { ...prev, [sanitized.id]: newProdMap };
      }
      return prev;
    });

    setExpandedProductIds((prev) => ({ ...prev, [sanitized.id]: true }));
    showToast(`품목 [${sanitized.code}] 및 차종 공급망 정보가 저장되었습니다.`);
  };

  // Delete Product
  const handleDeleteProduct = (productId: string) => {
    if (!isOwner) return;
    const prod = products.find((p) => p.id === productId);
    if (!prod) return;
    setProducts((prev) => prev.filter((p) => p.id !== productId));
    setDataStore((prev) => {
      const copy = { ...prev };
      delete copy[productId];
      return copy;
    });
    showToast(`품목 [${prod.code}]이(가) 삭제되었습니다.`);
  };

  // Beginning Stock Change (First day of week direct in-cell update)
  const handleBeginningStockChange = (
    productId: string,
    modelId: string | null,
    newStock: number
  ) => {
    if (!isOwner) return;
    const planMonth = dateList[0]?.slice(0, 7) || '2026-10';

    setProducts((prev) =>
      prev.map((p) => {
        if (p.id !== productId) return p;
        const validStock = Math.max(0, newStock);

        // Update monthlyInitialStocks ledger
        const existingLedger = p.monthlyInitialStocks || {};
        const curMonthRecord: MonthlyInitialStockRecord = existingLedger[planMonth] || {
          factory: p.factoryInitialStock,
          hubs: {},
        };

        if (!modelId) {
          const updatedMonthly = {
            ...existingLedger,
            [planMonth]: {
              ...curMonthRecord,
              factory: validStock,
            },
          };
          return {
            ...p,
            factoryInitialStock: validStock,
            monthlyInitialStocks: updatedMonthly,
          };
        }

        const targetModel = p.models.find((m) => m.id === modelId);
        if (targetModel) {
          const hubKey = targetModel.hubName || '울산 출고센터';
          const updatedHubLedger = {
            ...(curMonthRecord.hubs || {}),
            [hubKey]: validStock,
          };

          const updatedMonthly = {
            ...existingLedger,
            [planMonth]: {
              ...curMonthRecord,
              hubs: updatedHubLedger,
            },
          };

          // Also update unified hubs map on product
          const updatedHubs = { ...(p.hubs || {}) };
          updatedHubs[hubKey] = {
            hubName: hubKey,
            initialStock: validStock,
            safetyStock: updatedHubs[hubKey]?.safetyStock ?? 0,
            safetyDays: updatedHubs[hubKey]?.safetyDays ?? 5,
          };

          return {
            ...p,
            hubs: updatedHubs,
            monthlyInitialStocks: updatedMonthly,
            models: p.models.map((m) => {
              if (m.hubName !== targetModel.hubName) return m;
              return m.id === targetModel.id
                ? { ...m, initialStock: validStock }
                : { ...m, initialStock: 0 };
            }),
          };
        }
        return p;
      })
    );
    showToast(`거점 기초재고가 ${newStock.toLocaleString()}개로 업데이트되었습니다.`);
  };

  // Safety Stock Change (Auto-calc or direct in-cell update)
  const handleSafetyStockChange = (
    productId: string,
    modelId: string,
    newSafety: number
  ) => {
    if (!isOwner) return;
    setProducts((prev) =>
      prev.map((p) => {
        if (p.id !== productId) return p;
        const targetModel = p.models.find((m) => m.id === modelId);
        if (targetModel) {
          const hubKey = targetModel.hubName || '울산 출고센터';
          const validSafety = Math.max(0, newSafety);

          const updatedHubs = { ...(p.hubs || {}) };
          updatedHubs[hubKey] = {
            hubName: hubKey,
            initialStock: updatedHubs[hubKey]?.initialStock ?? 0,
            safetyStock: validSafety,
            safetyDays: 5,
          };

          return {
            ...p,
            hubs: updatedHubs,
            models: p.models.map((m) => {
              if (m.hubName !== targetModel.hubName) return m;
              return m.id === targetModel.id
                ? { ...m, safetyStock: validSafety, safetyDays: 5 }
                : { ...m, safetyStock: 0, safetyDays: 5 };
            }),
          };
        }
        return p;
      })
    );
    showToast(`거점 안전재고 기준(권장 5일분)이 ${newSafety.toLocaleString()}개로 설정되었습니다.`);
  };

  // Save Monthly Beginning Stock Ledger
  const handleSaveMonthlyInventory = (
    month: string,
    updatedData: Record<string, MonthlyInitialStockRecord>
  ) => {
    if (!isOwner) return;
    const currentMonth = dateList[0]?.slice(0, 7) || '2026-10';
    const isCurrentMonth = month === currentMonth;

    setProducts((prev) =>
      prev.map((p) => {
        const pUpdate = updatedData[p.id];
        if (!pUpdate) return p;

        const monthlyInitialStocks = {
          ...(p.monthlyInitialStocks || {}),
          [month]: pUpdate,
        };

        const updatedHubs = { ...(p.hubs || {}) };
        Object.entries(pUpdate.hubs).forEach(([hubName, stock]) => {
          updatedHubs[hubName] = {
            hubName,
            initialStock: stock,
            safetyStock: updatedHubs[hubName]?.safetyStock ?? 0,
            safetyDays: updatedHubs[hubName]?.safetyDays ?? 5,
          };
        });

        return {
          ...p,
          monthlyInitialStocks,
          hubs: updatedHubs,
          ...(isCurrentMonth ? { factoryInitialStock: pUpdate.factory } : {}),
        };
      })
    );
    showToast(`[${month}] 월별 기초재고 장부가 성공적으로 저장되었습니다.`);
  };

  // Reset to initial demo dataset
  const handleExecuteReset = () => {
    if (!isOwner) return;
    const resetDates = generateDateRange(14, 2);
    setProducts(INITIAL_PRODUCTS);
    setDataStore(generateInitialRecords(INITIAL_PRODUCTS, resetDates));
    localStorage.removeItem(STORAGE_KEY_PRODUCTS);
    localStorage.removeItem(STORAGE_KEY_DATA);
    setIsResetConfirmOpen(false);
    showToast('표준 공급망 데모 데이터셋으로 복원되었습니다.');
  };

  const isReadOnly = !isOwner;

  return (
    <div className="flex flex-col h-screen w-screen bg-slate-100 text-slate-800 font-sans select-none overflow-hidden">
      {/* 1. Header Navigation Bar with Week Selector & Permission Status */}
      <TopBar
        currentTab={currentTab}
        onTabChange={setCurrentTab}
        currentWeek={currentWeek}
        availableWeeks={availableWeeks}
        onSelectWeek={setCurrentWeek}
        onPrevWeek={handlePrevWeek}
        onNextWeek={handleNextWeek}
        isOwner={isOwner}
        currentUserEmail={currentUserEmail}
        onOpenWeeklyShareModal={() => setIsWeeklyShareModalOpen(true)}
        onOpenGoogleSyncModal={() => setIsGoogleSyncModalOpen(true)}
        onOpenAccessLogModal={() => setIsAccessLogModalOpen(true)}
        onOpenImportModal={() => setIsImportModalOpen(true)}
        onOpenNewProductModal={() => {
          setProductToEdit(null);
          setIsProductModalOpen(true);
        }}
        onExportCsv={handleExportCsv}
        onResetDemoData={() => setIsResetConfirmOpen(true)}
      />

      {/* 2. Secondary Filter & Quick Actions Toolbar (Only in Matrix tab) */}
      {currentTab === 'matrix' && (
        <FilterToolbar
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          products={products}
          selectedProductId={selectedProductId}
          onProductIdChange={setSelectedProductId}
          categories={categories}
          selectedCategory={selectedCategory}
          onCategoryChange={setSelectedCategory}
          vehicleModels={vehicleModels}
          selectedVehicleModel={selectedVehicleModel}
          onVehicleModelChange={setSelectedVehicleModel}
          hubs={hubs}
          selectedHub={selectedHub}
          onHubChange={setSelectedHub}
          startDateStr={startDateStr}
          onStartDateChange={handleStartDateChange}
          onPrevPeriod={handlePrevPeriod}
          onNextPeriod={handleNextPeriod}
          onJumpToday={handleJumpToday}
          daysRange={daysRange}
          onDaysRangeChange={setDaysRange}
          allExpanded={allExpanded}
          onToggleExpandAll={handleToggleExpandAll}
          allocationMode={allocationMode}
          onAllocationModeChange={setAllocationMode}
          onAutoAllocateAll={() => {
            showToast('공장 생산 및 거점 배분이 1 PLT 정배수로 정렬되었습니다.');
          }}
          onOpenForwardFillModal={() => {
            setForwardFillProductId('ALL');
            setIsForwardFillModalOpen(true);
          }}
          onOpenLineCapaModal={() => setIsLineCapaModalOpen(true)}
          isReadOnly={isReadOnly}
        />
      )}

      {/* 3. Main Dynamic Content Area */}
      <main className="flex-1 flex overflow-hidden">
        {currentTab === 'matrix' && (
          <MatrixGrid
            products={filteredProducts}
            dateList={dateList}
            dataStore={dataStore}
            selectedHub={selectedHub}
            selectedVehicleModel={selectedVehicleModel}
            expandedProductIds={expandedProductIds}
            onToggleProductExpand={handleToggleProductExpand}
            onCellChange={handleCellChange}
            onForwardFillField={handleForwardFillField}
            onBeginningStockChange={handleBeginningStockChange}
            onSafetyStockChange={handleSafetyStockChange}
            onOpenForwardFillModal={(pId) => {
              setForwardFillProductId(pId || 'ALL');
              setIsForwardFillModalOpen(true);
            }}
            onOpenLineCapaModal={() => setIsLineCapaModalOpen(true)}
            onEditProduct={(prod) => {
              setProductToEdit(prod);
              setIsProductModalOpen(true);
            }}
            isReadOnly={isReadOnly}
          />
        )}

        {currentTab === 'analytics' && (
          <TrendAnalytics
            products={filteredProducts}
            dateList={dateList}
            dataStore={dataStore}
          />
        )}

        {currentTab === 'products' && (
          <ProductMasterView
            products={products}
            currentDateMonth={dateList[0]?.slice(0, 7) || '2026-10'}
            onOpenNewProductModal={() => {
              setProductToEdit(null);
              setIsProductModalOpen(true);
            }}
            onEditProduct={(prod) => {
              setProductToEdit(prod);
              setIsProductModalOpen(true);
            }}
            onDeleteProduct={handleDeleteProduct}
            onSaveMonthlyInventory={handleSaveMonthlyInventory}
            isReadOnly={isReadOnly}
          />
        )}
      </main>

      {/* 4. Bottom Info Strip */}
      <footer className="px-6 py-2 bg-white border-t border-slate-200 flex items-center justify-between text-[11px] text-slate-500 shrink-0">
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1 font-medium text-slate-700">
            <Info className="w-3.5 h-3.5 text-blue-600" />
            <span>다거점 공급망 파이프라인:</span>
          </span>
          <span className="font-semibold text-slate-800">1. 공장 단일 생산 풀</span>
          <span>&rarr;</span>
          <span className="text-blue-700 font-semibold">2. 고객사별 차종 지정 출고센터 (울산/광주/화성/아산)</span>
          <span>&rarr;</span>
          <span className="text-indigo-700 font-semibold">3. 전체 물류총재고 통합 롤업</span>
          <span>·</span>
          <span>1 PLT 상차단위 자동안분</span>
        </div>

        <div className="flex items-center gap-2">
          <span>
            선택 주차: <strong className="font-mono text-slate-800">{currentWeek.weekId}</strong>
          </span>
          <span>·</span>
          <span>
            권한:{' '}
            <strong className={isOwner ? 'text-amber-700 font-semibold' : 'text-slate-600'}>
              {isOwner ? '소유자(수정·배포)' : '읽기 전용'}
            </strong>
          </span>
          <span>·</span>
          <span>
            등록 품목: <strong className="font-mono text-slate-800">{products.length}</strong>개
          </span>
        </div>
      </footer>

      {/* Modals */}
      <ProductModal
        isOpen={isProductModalOpen}
        onClose={() => setIsProductModalOpen(false)}
        onSave={handleSaveProduct}
        productToEdit={productToEdit}
      />

      <CsvImportModal
        isOpen={isImportModalOpen}
        onClose={() => setIsImportModalOpen(false)}
        products={products}
        dateList={dateList}
        dataStore={dataStore}
        onImportSuccess={(newStore) => {
          setDataStore(newStore);
          showToast('CSV 데이터가 정상적으로 시스템에 반영되었습니다.');
        }}
      />

      {/* Legacy Share / Backup Modal */}
      <ShareModal
        isOpen={isShareModalOpen}
        onClose={() => setIsShareModalOpen(false)}
        products={products}
        dataStore={dataStore}
        onImportWorkspace={handleImportWorkspace}
        onExportCsv={handleExportCsv}
        onShowToast={showToast}
      />

      {/* Weekly Share Modal (Week-by-week read-only distribution) */}
      <WeeklyShareModal
        isOpen={isWeeklyShareModalOpen}
        onClose={() => setIsWeeklyShareModalOpen(false)}
        currentWeek={currentWeek}
        products={products}
        dateList={dateList}
        dataStore={dataStore}
        ownerEmail={OWNER_EMAIL}
        isOwner={isOwner}
        onShowToast={showToast}
      />

      {/* Google Sheets Sync Modal (Sync to owner's Google Drive) */}
      <GoogleSheetsSyncModal
        isOpen={isGoogleSyncModalOpen}
        onClose={() => setIsGoogleSyncModalOpen(false)}
        currentWeek={currentWeek}
        products={products}
        dateList={dateList}
        dataStore={dataStore}
        currentUserEmail={currentUserEmail}
        isOwner={isOwner}
        onAuthSuccess={(email, isOwnerResult) => {
          setCurrentUserEmail(email);
          setIsOwner(isOwnerResult);
        }}
        onAuthSignOut={() => {
          setCurrentUserEmail(null);
          setIsOwner(false);
        }}
        onShowToast={showToast}
      />

      {/* Forward Fill Modal */}
      <ForwardFillModal
        isOpen={isForwardFillModalOpen}
        onClose={() => setIsForwardFillModalOpen(false)}
        products={products}
        selectedProductId={forwardFillProductId}
        dateList={dateList}
        onApplyBatchFill={handleBatchForwardFillPlans}
      />

      {/* Line CAPA & Production Scheduling Modal */}
      <LineCapaModal
        isOpen={isLineCapaModalOpen}
        onClose={() => setIsLineCapaModalOpen(false)}
        products={products}
        dateList={dateList}
        dataStore={dataStore}
        onApplyCapaPlans={(newStore) => {
          setDataStore(newStore);
        }}
        onShowToast={showToast}
      />

      {/* Access Log Monitoring Modal (Owner Only) */}
      <AccessLogModal
        isOpen={isAccessLogModalOpen}
        onClose={() => setIsAccessLogModalOpen(false)}
        onShowToast={showToast}
      />

      {/* In-App Reset Confirmation Modal */}
      {isResetConfirmOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-4 animate-in fade-in duration-100">
          <div className="bg-white rounded-lg shadow-xl border border-slate-200 w-full max-w-md overflow-hidden">
            <div className="p-5">
              <div className="flex items-start gap-3">
                <div className="w-9 h-9 rounded-full bg-amber-100 text-amber-700 flex items-center justify-center shrink-0">
                  <RotateCcw className="w-5 h-5" />
                </div>
                <div className="flex-1">
                  <h3 className="text-sm font-bold text-slate-900">
                    초기 데모 데이터셋 복원
                  </h3>
                  <p className="text-xs text-slate-600 mt-1">
                    기존에 입력하거나 수정한 모든 품목과 일자별 데이터가 표준 데모 상태로 초기화됩니다. 계속 진행하시겠습니까?
                  </p>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 mt-5 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsResetConfirmOpen(false)}
                  className="px-3 py-1.5 text-xs font-medium text-slate-600 hover:bg-slate-100 rounded transition-colors"
                >
                  취소
                </button>
                <button
                  type="button"
                  onClick={handleExecuteReset}
                  className="px-4 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded shadow-xs transition-colors"
                >
                  초기화 진행
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Toast Notification Popup */}
      {toastMessage && (
        <div className="fixed bottom-12 right-6 z-50 flex items-center gap-2 px-4 py-2.5 bg-slate-900 text-white rounded-lg shadow-lg border border-slate-800 text-xs font-medium animate-in fade-in slide-in-from-bottom-2 duration-150">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
}
