import React, { useState } from 'react';
import {
  X,
  Share2,
  Copy,
  Check,
  Download,
  Upload,
  FileSpreadsheet,
  FileCode,
  Sparkles,
  Info,
  ExternalLink,
  ShieldCheck,
} from 'lucide-react';
import { ProductItem, PsiDataStore } from '../types/psi';
import { exportWorkspaceToJson, generateShareableUrl, importWorkspaceFromJson } from '../utils/shareUtils';
import { downloadFile } from '../utils/psiEngine';

interface ShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: ProductItem[];
  dataStore: PsiDataStore;
  onImportWorkspace: (products: ProductItem[], dataStore: PsiDataStore) => void;
  onExportCsv: () => void;
  onShowToast: (msg: string) => void;
}

export const ShareModal: React.FC<ShareModalProps> = ({
  isOpen,
  onClose,
  products,
  dataStore,
  onImportWorkspace,
  onExportCsv,
  onShowToast,
}) => {
  const [copiedLink, setCopiedLink] = useState(false);
  const [importError, setImportError] = useState<string | null>(null);

  if (!isOpen) return null;

  // 1. Generate shareable URL
  const shareableUrl = generateShareableUrl(products, dataStore);

  const handleCopyLink = async () => {
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(shareableUrl);
      } else {
        const textarea = document.createElement('textarea');
        textarea.value = shareableUrl;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
      }
      setCopiedLink(true);
      onShowToast('🔗 업데이트본 공유 링크가 클립보드에 복사되었습니다!');
      setTimeout(() => setCopiedLink(false), 2500);
    } catch {
      onShowToast('링크 복사에 실패했습니다. URL을 직접 복사해주세요.');
    }
  };

  // 2. Export workspace JSON
  const handleExportJson = () => {
    const jsonStr = exportWorkspaceToJson(products, dataStore);
    const dateStamp = new Date().toISOString().slice(0, 10);
    downloadFile(jsonStr, `PSI_Flow_Workspace_${dateStamp}.json`, 'application/json');
    onShowToast('💾 작업본 JSON 파일이 다운로드되었습니다.');
  };

  // 3. Import workspace JSON
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    setImportError(null);
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const content = event.target?.result as string;
        const { products: importedProds, dataStore: importedStore } = importWorkspaceFromJson(content);
        onImportWorkspace(importedProds, importedStore);
        onShowToast(`📂 [${file.name}] 파일의 데이터(${importedProds.length}개 품목)를 성공적으로 불러왔습니다!`);
        onClose();
      } catch (err: any) {
        setImportError(err.message || '파일 불러오기 중 오류가 발생했습니다.');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-slate-900 text-white">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-blue-600/30 text-blue-400 border border-blue-500/30">
              <Share2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white leading-tight">작업본 공유 및 동료 전달 (Share & Update)</h3>
              <p className="text-xs text-slate-300 mt-0.5">
                내가 수정한 생산·소요량 계획 및 신규 추가 품목을 동료에게 그대로 전달하는 3가지 방법
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-5 max-h-[75vh] overflow-y-auto">
          {/* Method 1: Instant URL Link Share */}
          <div className="p-4 rounded-lg border-2 border-blue-100 bg-blue-50/40 relative">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <span className="flex items-center justify-center w-5 h-5 rounded-full bg-blue-600 text-white text-xs font-bold">
                  1
                </span>
                <span className="text-sm font-bold text-slate-900">추천: 1초 초고속 공유 링크 (URL 스냅샷)</span>
                <span className="px-2 py-0.5 text-[10px] font-semibold bg-blue-100 text-blue-700 rounded-full">
                  설치 불필요
                </span>
              </div>
            </div>
            <p className="text-xs text-slate-600 mb-3">
              현재 작업 중인 <strong>모든 품목 마스터({products.length}개)</strong>와 <strong>일자별 수기 수정값</strong>이 링크 주소 안에 안전하게 압축 포함되어 있습니다. 동료가 이 링크를 열기만 하면 내 작업 화면이 1초 만에 그대로 복원됩니다.
            </p>

            <div className="flex items-center gap-2">
              <input
                type="text"
                readOnly
                value={shareableUrl}
                className="flex-1 px-3 py-2 text-xs font-mono bg-white border border-slate-300 rounded-lg text-slate-600 truncate focus:outline-none"
              />
              <button
                type="button"
                onClick={handleCopyLink}
                className={`flex items-center gap-1.5 px-4 py-2 text-xs font-semibold rounded-lg text-white transition-all shadow-xs shrink-0 ${
                  copiedLink
                    ? 'bg-emerald-600 hover:bg-emerald-500'
                    : 'bg-blue-600 hover:bg-blue-500 active:scale-95'
                }`}
              >
                {copiedLink ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                <span>{copiedLink ? '복사 완료!' : '공유 링크 복사'}</span>
              </button>
            </div>
          </div>

          {/* Method 2: Workspace JSON File Export & Import */}
          <div className="p-4 rounded-lg border border-slate-200 bg-slate-50/60">
            <div className="flex items-center gap-2 mb-2">
              <span className="flex items-center justify-center w-5 h-5 rounded-full bg-slate-700 text-white text-xs font-bold">
                2
              </span>
              <span className="text-sm font-bold text-slate-900">작업본 파일 전달 (.json 백업 및 복원)</span>
              <span className="px-2 py-0.5 text-[10px] font-semibold bg-slate-200 text-slate-700 rounded-full">
                메신저·메일 첨부용
              </span>
            </div>
            <p className="text-xs text-slate-600 mb-3">
              사내 슬랙, 카카오톡, 잔디, 이메일에 첨부 파일로 전달할 때 가장 확실한 방법입니다. 받는 동료는 '파일 불러오기'로 즉시 동일 데이터를 열람합니다.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <button
                type="button"
                onClick={handleExportJson}
                className="flex items-center justify-center gap-2 px-3.5 py-2.5 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-300 rounded-lg transition-colors shadow-2xs"
              >
                <Download className="w-4 h-4 text-blue-600" />
                <span>내 작업본 파일 저장 (.json)</span>
              </button>

              <label className="flex items-center justify-center gap-2 px-3.5 py-2.5 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-300 rounded-lg transition-colors shadow-2xs cursor-pointer">
                <Upload className="w-4 h-4 text-emerald-600" />
                <span>동료 작업본 파일 불러오기</span>
                <input
                  type="file"
                  accept=".json,application/json"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>
            </div>

            {importError && (
              <p className="mt-2 text-xs text-red-600 font-medium">⚠️ {importError}</p>
            )}
          </div>

          {/* Method 3: Excel CSV Download */}
          <div className="p-4 rounded-lg border border-slate-200 bg-slate-50/60">
            <div className="flex items-center gap-2 mb-2">
              <span className="flex items-center justify-center w-5 h-5 rounded-full bg-slate-700 text-white text-xs font-bold">
                3
              </span>
              <span className="text-sm font-bold text-slate-900">엑셀(CSV) 보고서 공유</span>
              <span className="px-2 py-0.5 text-[10px] font-semibold bg-emerald-100 text-emerald-700 rounded-full">
                결재·보고용
              </span>
            </div>
            <p className="text-xs text-slate-600 mb-3">
              시스템에 직접 접속하지 않는 유관부서(영업, 공장장 등)나 결재 보고 시 한글(UTF-8 BOM) 깨짐 없는 엑셀 파일로 전달할 수 있습니다.
            </p>
            <button
              type="button"
              onClick={() => {
                onExportCsv();
                onClose();
              }}
              className="flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 rounded-lg transition-colors"
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
              <span>엑셀(CSV) 다운로드</span>
            </button>
          </div>

          {/* Information Notice */}
          <div className="flex items-start gap-2.5 p-3 rounded-lg bg-amber-50 border border-amber-200 text-amber-900 text-xs leading-relaxed">
            <Info className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold">💡 왜 기본 링크만 주면 수정한 내용이 안 보일까요?</p>
              <p className="text-amber-800 mt-0.5">
                웹 브라우저의 보안 특성상 내가 수정한 데이터는 내 PC 브라우저(로컬 저장소)에만 안전하게 보관됩니다. 따라서 동료에게 수정본을 줄 때는 <strong>[1번 공유 링크]</strong> 또는 <strong>[2번 JSON 파일]</strong>을 전달해 주셔야 합니다. 기본 배포 데이터 자체를 변경하고 싶으신 경우 언제든 말씀해주시면 영구 반영해 드립니다!
              </p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end px-6 py-3 bg-slate-50 border-t border-slate-200">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-700 bg-white hover:bg-slate-100 border border-slate-300 rounded-lg transition-colors"
          >
            닫기
          </button>
        </div>
      </div>
    </div>
  );
};
