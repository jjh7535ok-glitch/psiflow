import React, { useState } from 'react';
import {
  Download,
  Upload,
  Plus,
  RotateCcw,
  TableProperties,
  BarChart3,
  Package,
  Share2,
  FileSpreadsheet,
  Calendar,
  ChevronLeft,
  ChevronRight,
  ShieldCheck,
  Lock,
  Eye,
} from 'lucide-react';
import { WeekInfo } from '../utils/weeklyUtils';

interface TopBarProps {
  currentTab: 'matrix' | 'analytics' | 'products';
  onTabChange: (tab: 'matrix' | 'analytics' | 'products') => void;
  currentWeek: WeekInfo;
  onPrevWeek: () => void;
  onNextWeek: () => void;
  onSelectWeek: (week: WeekInfo) => void;
  availableWeeks: WeekInfo[];
  isOwner: boolean;
  currentUserEmail: string | null;
  onOpenGoogleSyncModal: () => void;
  onOpenWeeklyShareModal: () => void;
  onOpenAccessLogModal?: () => void;
  onExportCsv: () => void;
  onOpenImportModal: () => void;
  onOpenNewProductModal: () => void;
  onResetDemoData: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  currentTab,
  onTabChange,
  currentWeek,
  onPrevWeek,
  onNextWeek,
  onSelectWeek,
  availableWeeks,
  isOwner,
  currentUserEmail,
  onOpenGoogleSyncModal,
  onOpenWeeklyShareModal,
  onOpenAccessLogModal,
  onExportCsv,
  onOpenImportModal,
  onOpenNewProductModal,
  onResetDemoData,
}) => {
  const [showWeekDropdown, setShowWeekDropdown] = useState(false);

  return (
    <header className="flex items-center justify-between gap-6 px-6 py-3 bg-slate-900 border-b border-slate-800 text-white shrink-0">
      {/* Zone 1: Wordmark & Week Navigator */}
      <div className="flex items-center gap-4 shrink-0">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded bg-blue-600 flex items-center justify-center font-bold text-white tracking-wider text-xs shadow-xs">
            PSI
          </div>
          <div className="flex flex-col">
            <span className="text-sm font-bold tracking-tight text-white whitespace-nowrap">
              PSI Flow
            </span>
            <span className="text-[10px] text-slate-400 font-medium whitespace-nowrap">
              다거점 공급망 관리
            </span>
          </div>
        </div>

        {/* Weekly Navigator Selector */}
        <div className="relative flex items-center bg-slate-800/90 rounded-md border border-slate-700/80 p-0.5">
          <button
            type="button"
            onClick={onPrevWeek}
            title="이전 주차"
            className="p-1 hover:bg-slate-700 text-slate-300 hover:text-white rounded transition-colors"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
          </button>

          <button
            type="button"
            onClick={() => setShowWeekDropdown(!showWeekDropdown)}
            className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold text-slate-200 hover:text-white transition-colors"
          >
            <Calendar className="w-3.5 h-3.5 text-blue-400" />
            <span className="font-mono text-[11px]">{currentWeek.weekId}</span>
            <span className="hidden lg:inline text-[11px] text-slate-400 font-normal">
              ({currentWeek.startDateStr.slice(5).replace('-', '/')}~{currentWeek.endDateStr.slice(5).replace('-', '/')})
            </span>
          </button>

          <button
            type="button"
            onClick={onNextWeek}
            title="다음 주차"
            className="p-1 hover:bg-slate-700 text-slate-300 hover:text-white rounded transition-colors"
          >
            <ChevronRight className="w-3.5 h-3.5" />
          </button>

          {/* Week Dropdown */}
          {showWeekDropdown && (
            <div className="absolute top-full left-0 mt-1 z-50 w-64 bg-slate-800 border border-slate-700 rounded-lg shadow-xl py-1 text-xs text-slate-200">
              <div className="px-3 py-1.5 text-[10px] font-bold text-slate-400 border-b border-slate-700 uppercase tracking-wider">
                주차별 계획 선택
              </div>
              <div className="max-h-56 overflow-y-auto">
                {availableWeeks.map((w) => (
                  <button
                    key={w.weekId}
                    type="button"
                    onClick={() => {
                      onSelectWeek(w);
                      setShowWeekDropdown(false);
                    }}
                    className={`w-full text-left px-3 py-1.5 flex items-center justify-between hover:bg-slate-700/70 transition-colors ${
                      w.weekId === currentWeek.weekId
                        ? 'bg-blue-600/30 text-blue-300 font-semibold'
                        : ''
                    }`}
                  >
                    <span className="font-mono">{w.weekId}</span>
                    <span className="text-[11px] text-slate-400">{w.weekLabel}</span>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Zone 2: Navigation Links / Segmented Tabs */}
      <nav className="flex items-center gap-1 p-1 bg-slate-800/90 rounded-lg border border-slate-700/60 shrink-0">
        <button
          type="button"
          onClick={() => onTabChange('matrix')}
          className={`flex items-center gap-1.5 px-3 py-1 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
            currentTab === 'matrix'
              ? 'bg-blue-600 text-white shadow-xs'
              : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
          }`}
        >
          <TableProperties className="w-3.5 h-3.5" />
          <span>매트릭스 그리드</span>
        </button>

        <button
          type="button"
          onClick={() => onTabChange('analytics')}
          className={`flex items-center gap-1.5 px-3 py-1 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
            currentTab === 'analytics'
              ? 'bg-blue-600 text-white shadow-xs'
              : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
          }`}
        >
          <BarChart3 className="w-3.5 h-3.5" />
          <span>추이 분석 차트</span>
        </button>

        <button
          type="button"
          onClick={() => onTabChange('products')}
          className={`flex items-center gap-1.5 px-3 py-1 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
            currentTab === 'products'
              ? 'bg-blue-600 text-white shadow-xs'
              : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
          }`}
        >
          <Package className="w-3.5 h-3.5" />
          <span>품목 마스터</span>
        </button>
      </nav>

      {/* Zone 3: Primary Actions & Governance Status */}
      <div className="flex items-center gap-2 shrink-0">
        {/* Ownership Badge / Read-only Indicator */}
        {isOwner ? (
          <div className="hidden md:flex items-center gap-1.5 px-2.5 py-1 text-[11px] font-semibold text-amber-300 bg-amber-950/60 border border-amber-600/50 rounded whitespace-nowrap">
            <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
            <span>소유자(수정·배포 권한)</span>
          </div>
        ) : (
          <div className="hidden md:flex items-center gap-1.5 px-2.5 py-1 text-[11px] font-medium text-slate-300 bg-slate-800/80 border border-slate-700 rounded whitespace-nowrap">
            <Lock className="w-3.5 h-3.5 text-slate-400" />
            <span>읽기 전용 (Read-Only)</span>
          </div>
        )}

        {/* Google Sheets Sync (Active for all, login triggered if needed) */}
        <button
          type="button"
          onClick={onOpenGoogleSyncModal}
          className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold text-emerald-300 bg-emerald-950/70 hover:bg-emerald-900/90 rounded border border-emerald-600/60 transition-colors whitespace-nowrap shadow-xs"
          title="Google Drive / Sheets로 주차별 데이터 저장"
        >
          <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
          <span>Google 시트 동기화</span>
        </button>

        {/* Weekly Share Link */}
        <button
          type="button"
          onClick={onOpenWeeklyShareModal}
          className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold text-sky-200 bg-sky-950/70 hover:bg-sky-900/90 rounded border border-sky-600/60 transition-colors whitespace-nowrap shadow-xs"
          title="주차별 확정본 읽기 전용 공유 링크 발급"
        >
          <Share2 className="w-3.5 h-3.5 text-sky-400" />
          <span>주차별 링크 공유</span>
        </button>

        <button
          type="button"
          onClick={onExportCsv}
          className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-300 hover:text-white hover:bg-slate-800 rounded border border-slate-700 transition-colors whitespace-nowrap"
          title="엑셀 CSV 파일 다운로드"
        >
          <Download className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">CSV</span>
        </button>

        {/* Owner-only Actions */}
        {isOwner && (
          <>
            {onOpenAccessLogModal && (
              <button
                type="button"
                onClick={onOpenAccessLogModal}
                className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold text-emerald-300 bg-emerald-950/80 hover:bg-emerald-900 rounded border border-emerald-600/60 shadow-xs transition-colors whitespace-nowrap"
                title="배포 링크를 열람한 사용자 접속 이력 모니터링 (소유자 전용)"
              >
                <Eye className="w-3.5 h-3.5 text-emerald-400" />
                <span>열람 이력</span>
              </button>
            )}

            <button
              type="button"
              onClick={onOpenNewProductModal}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded shadow-xs transition-colors whitespace-nowrap"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>품목 등록</span>
            </button>

            <button
              type="button"
              onClick={onResetDemoData}
              title="초기 샘플 데이터 복원"
              className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded border border-slate-700 transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </>
        )}
      </div>
    </header>
  );
};
