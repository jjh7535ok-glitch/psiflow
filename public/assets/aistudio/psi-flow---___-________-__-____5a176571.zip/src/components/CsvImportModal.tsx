import React, { useState } from 'react';
import { X, Upload, FileText, AlertCircle, Check } from 'lucide-react';
import { ProductItem, PsiDataStore } from '../types/psi';
import { downloadFile, exportToCsv } from '../utils/psiEngine';

interface CsvImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: ProductItem[];
  dateList: string[];
  dataStore: PsiDataStore;
  onImportSuccess: (importedStore: PsiDataStore) => void;
}

export const CsvImportModal: React.FC<CsvImportModalProps> = ({
  isOpen,
  onClose,
  products,
  dateList,
  dataStore,
  onImportSuccess,
}) => {
  const [csvText, setCsvText] = useState('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      setCsvText(content);
      setErrorMsg(null);
    };
    reader.onerror = () => {
      setErrorMsg('파일을 읽는 도중 오류가 발생했습니다.');
    };
    reader.readAsText(file, 'utf-8');
  };

  const handleDownloadSample = () => {
    const sampleCsv = exportToCsv(products, dateList, dataStore);
    downloadFile(sampleCsv, 'PSI_Template_Sample.csv');
  };

  const handleProcessImport = () => {
    setErrorMsg(null);
    setSuccessMsg(null);

    if (!csvText.trim()) {
      setErrorMsg('CSV 데이터를 입력하거나 파일을 업로드해 주세요.');
      return;
    }

    try {
      // Clean BOM if present
      const cleanText = csvText.replace(/^\uFEFF/, '');
      const lines = cleanText.split(/\r?\n/).filter((l) => l.trim().length > 0);

      if (lines.length < 2) {
        setErrorMsg('유효한 CSV 형식이 아닙니다 (최소 2행 이상 필요).');
        return;
      }

      // Parse headers
      const headers = lines[0].split(',').map((h) => h.replace(/^"|"$/g, '').trim());
      
      // Find dynamic column indices
      const codeIdx = headers.findIndex((h) => h.includes('코드'));
      const hubIdx = headers.findIndex((h) => h.includes('거점') || h.includes('계층'));
      const metricIdx = headers.findIndex((h) => h.includes('지표'));

      if (codeIdx === -1 || hubIdx === -1 || metricIdx === -1) {
        setErrorMsg('헤더에 품목코드, 거점/계층구분, 지표명 열이 반드시 포함되어야 합니다.');
        return;
      }

      const dateStartIdx = Math.max(hubIdx, metricIdx) + 1;
      const datesInCsv = headers.slice(dateStartIdx);

      if (datesInCsv.length === 0) {
        setErrorMsg('헤더에 일자 열(YYYY-MM-DD)이 존재하지 않습니다.');
        return;
      }

      const newStore: PsiDataStore = JSON.parse(JSON.stringify(dataStore));
      let updatedCount = 0;

      // Loop through data rows
      for (let i = 1; i < lines.length; i++) {
        const cols = lines[i].split(',').map((c) => c.replace(/^"|"$/g, '').trim());
        if (cols.length <= dateStartIdx) continue;

        const prodCode = cols[codeIdx];
        const hub = cols[hubIdx];
        const metric = cols[metricIdx];

        const matchingProduct = products.find((p) => p.code === prodCode);
        if (!matchingProduct) continue;

        if (!newStore[matchingProduct.id]) {
          newStore[matchingProduct.id] = {};
        }

        // Parse date values
        datesInCsv.forEach((dStr, idx) => {
          const val = parseInt(cols[dateStartIdx + idx] || '0', 10) || 0;
          if (!newStore[matchingProduct.id][dStr]) {
            newStore[matchingProduct.id][dStr] = {
              prodPlan: 0,
              prodActual: 0,
              ulsanAlloc: 0,
              ulsanPlan: 0,
              ulsanActual: 0,
              gwangjuAlloc: 0,
              gwangjuPlan: 0,
              gwangjuActual: 0,
            };
          }

          const rec = newStore[matchingProduct.id][dStr];
          if (hub.includes('공장') && metric.includes('계획')) rec.prodPlan = val;
          else if (hub.includes('공장') && metric.includes('실적')) rec.prodActual = val;
          else if (hub.includes('울산') && metric.includes('배분')) rec.ulsanAlloc = val;
          else if (hub.includes('울산') && metric.includes('계획')) rec.ulsanPlan = val;
          else if (hub.includes('울산') && metric.includes('실적')) rec.ulsanActual = val;
          else if (hub.includes('광주') && metric.includes('배분')) rec.gwangjuAlloc = val;
          else if (hub.includes('광주') && metric.includes('계획')) rec.gwangjuPlan = val;
          else if (hub.includes('광주') && metric.includes('실적')) rec.gwangjuActual = val;
        });

        updatedCount++;
      }

      onImportSuccess(newStore);
      setSuccessMsg(`성공적으로 ${updatedCount}개 행의 데이터를 반영했습니다.`);
      setTimeout(() => {
        onClose();
      }, 800);
    } catch {
      setErrorMsg('CSV 파싱 중 오류가 발생했습니다. 파일 형식을 확인해 주세요.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-4">
      <div className="bg-white rounded-lg shadow-xl border border-slate-200 w-full max-w-xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 bg-slate-900 text-white">
          <h2 className="text-sm font-bold tracking-tight flex items-center gap-2">
            <Upload className="w-4 h-4 text-blue-400" />
            <span>CSV 엑셀 데이터 가져오기</span>
          </h2>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4 text-xs">
          <div className="flex items-center justify-between bg-slate-50 p-3 rounded border border-slate-200">
            <div>
              <p className="font-semibold text-slate-800">표준 템플릿 양식 다운로드</p>
              <p className="text-[11px] text-slate-500 mt-0.5">
                현재 등록된 품목과 일자 구조가 적용된 CSV 샘플을 내려받을 수 있습니다.
              </p>
            </div>
            <button
              type="button"
              onClick={handleDownloadSample}
              className="px-2.5 py-1.5 bg-white border border-slate-300 rounded font-medium text-slate-700 hover:bg-slate-100 transition-colors whitespace-nowrap"
            >
              템플릿 받기
            </button>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              CSV 파일 업로드
            </label>
            <input
              type="file"
              accept=".csv"
              onChange={handleFileUpload}
              className="block w-full text-xs text-slate-500 file:mr-3 file:py-1.5 file:px-3 file:rounded file:border-0 file:text-xs file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100 cursor-pointer"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1 flex items-center justify-between">
              <span>또는 CSV 원본 텍스트 직접 붙여넣기</span>
              <FileText className="w-3.5 h-3.5 text-slate-400" />
            </label>
            <textarea
              rows={6}
              value={csvText}
              onChange={(e) => setCsvText(e.target.value)}
              placeholder="품목코드,품목명,단위,거점구분,지표명,2026-10-18,2026-10-19..."
              className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded font-mono text-[11px] text-slate-800 focus:bg-white focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
          </div>

          {errorMsg && (
            <div className="p-2.5 bg-rose-50 border border-rose-200 rounded text-rose-700 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {successMsg && (
            <div className="p-2.5 bg-emerald-50 border border-emerald-200 rounded text-emerald-700 flex items-center gap-2">
              <Check className="w-4 h-4 shrink-0" />
              <span>{successMsg}</span>
            </div>
          )}

          {/* Modal Actions */}
          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-1.5 rounded text-xs font-medium text-slate-600 hover:bg-slate-100 transition-colors"
            >
              닫기
            </button>
            <button
              type="button"
              onClick={handleProcessImport}
              className="flex items-center gap-1.5 px-4 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded text-xs font-semibold shadow-xs transition-colors"
            >
              <Upload className="w-3.5 h-3.5" />
              <span>가져오기 적용</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
