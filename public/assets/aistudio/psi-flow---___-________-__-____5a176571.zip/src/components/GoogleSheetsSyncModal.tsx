import React, { useState } from 'react';
import {
  X,
  FileSpreadsheet,
  CheckCircle2,
  AlertTriangle,
  Loader2,
  ExternalLink,
  ShieldAlert,
  LogIn,
  LogOut,
  RefreshCw,
} from 'lucide-react';
import { ProductItem, PsiDataStore } from '../types/psi';
import { WeekInfo } from '../utils/weeklyUtils';
import {
  googleSignIn,
  googleSignOut,
  getAccessToken,
  OWNER_EMAIL,
} from '../services/googleAuth';
import {
  syncWeeklyPlanToGoogleSheets,
  SyncResult,
} from '../services/googleSheetsService';

interface GoogleSheetsSyncModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentWeek: WeekInfo;
  products: ProductItem[];
  dateList: string[];
  dataStore: PsiDataStore;
  currentUserEmail: string | null;
  isOwner: boolean;
  onAuthSuccess: (email: string, isOwner: boolean) => void;
  onAuthSignOut: () => void;
  onShowToast: (msg: string) => void;
}

export const GoogleSheetsSyncModal: React.FC<GoogleSheetsSyncModalProps> = ({
  isOpen,
  onClose,
  currentWeek,
  products,
  dateList,
  dataStore,
  currentUserEmail,
  isOwner,
  onAuthSuccess,
  onAuthSignOut,
  onShowToast,
}) => {
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncStep, setSyncStep] = useState<string>('');
  const [syncResult, setSyncResult] = useState<SyncResult | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleLogin = async () => {
    try {
      setErrorMsg(null);
      const res = await googleSignIn();
      if (res) {
        onAuthSuccess(res.user.email || '', res.isOwner);
        if (res.isOwner) {
          onShowToast(`👑 소유자 계정(${res.user.email})으로 성공적으로 연결되었습니다.`);
        } else {
          onShowToast(`Google 계정(${res.user.email})으로 연결되었습니다. (읽기 전용 모드)`);
        }
      }
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || 'Google 로그인 중 오류가 발생했습니다.');
    }
  };

  const handleLogout = async () => {
    await googleSignOut();
    onAuthSignOut();
    setSyncResult(null);
    onShowToast('Google 계정 로그아웃되었습니다.');
  };

  const handleSyncToSheets = async () => {
    try {
      setIsSyncing(true);
      setErrorMsg(null);
      setSyncStep('인증 토큰 확인 중...');

      let token = await getAccessToken();
      if (!token) {
        setSyncStep('Google 계정 인증 진행 중...');
        const loginRes = await googleSignIn();
        if (!loginRes) {
          throw new Error('Google 로그인이 필요합니다.');
        }
        token = loginRes.accessToken;
        onAuthSuccess(loginRes.user.email || '', loginRes.isOwner);
      }

      setSyncStep('내 Google Drive 스프레드시트 탐색 및 생성 중...');
      const result = await syncWeeklyPlanToGoogleSheets({
        accessToken: token,
        weekId: currentWeek.weekId,
        weekLabel: currentWeek.weekLabel,
        products,
        dateList,
        dataStore,
        ownerEmail: OWNER_EMAIL,
      });

      setSyncResult(result);
      onShowToast(`[${currentWeek.weekId}] 주차 데이터가 Google Sheets로 성공적으로 동기화되었습니다!`);
    } catch (err: any) {
      console.error('Sync failed:', err);
      setErrorMsg(err.message || '스프레드시트 동기화 중 오류가 발생했습니다.');
    } finally {
      setIsSyncing(false);
      setSyncStep('');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 animate-in fade-in duration-150">
      <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-lg overflow-hidden flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 bg-emerald-950 text-white flex items-center justify-between border-b border-emerald-900/50">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-600 flex items-center justify-center text-white">
              <FileSpreadsheet className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white flex items-center gap-2">
                <span>Google Sheets 동기화</span>
                <span className="px-2 py-0.5 rounded text-[11px] font-mono bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">
                  {currentWeek.weekId}
                </span>
              </h2>
              <p className="text-[11px] text-emerald-300/80 mt-0.5">
                내 Google Drive에 스프레드시트 자동 생성 및 주차별 탭 동기화
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded text-emerald-300 hover:text-white hover:bg-emerald-900 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5 text-xs text-slate-700 overflow-y-auto max-h-[75vh]">
          {/* Account & Authority Status */}
          <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-lg flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div
                className={`w-7 h-7 rounded-full flex items-center justify-center font-bold text-xs ${
                  isOwner
                    ? 'bg-amber-100 text-amber-800 border border-amber-300'
                    : currentUserEmail
                    ? 'bg-slate-200 text-slate-700'
                    : 'bg-slate-100 text-slate-400'
                }`}
              >
                {isOwner ? '👑' : '👤'}
              </div>
              <div>
                <p className="font-semibold text-slate-900 text-xs">
                  {currentUserEmail ? (
                    <>
                      <span>{currentUserEmail}</span>
                      {isOwner && (
                        <span className="ml-1.5 px-1.5 py-0.5 text-[10px] font-semibold bg-amber-100 text-amber-800 rounded">
                          소유자(관리자)
                        </span>
                      )}
                    </>
                  ) : (
                    <span className="text-slate-500">Google 계정 미연결</span>
                  )}
                </p>
                <p className="text-[11px] text-slate-500">
                  {isOwner
                    ? 'Google Drive/Sheets 수정 및 주차별 배포 권한 활성화'
                    : `지정 소유자: ${OWNER_EMAIL}`}
                </p>
              </div>
            </div>

            <div>
              {currentUserEmail ? (
                <button
                  type="button"
                  onClick={handleLogout}
                  className="flex items-center gap-1 px-2.5 py-1 text-[11px] font-medium text-slate-600 hover:text-slate-900 bg-white border border-slate-200 rounded hover:bg-slate-100 transition-colors"
                >
                  <LogOut className="w-3 h-3" />
                  <span>로그아웃</span>
                </button>
              ) : (
                <button
                  type="button"
                  onClick={handleLogin}
                  className="flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded transition-colors shadow-xs"
                >
                  <LogIn className="w-3.5 h-3.5" />
                  <span>Google 로그인</span>
                </button>
              )}
            </div>
          </div>

          {/* Non-owner Warning */}
          {currentUserEmail && !isOwner && (
            <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg flex items-start gap-2.5">
              <ShieldAlert className="w-4 h-4 text-amber-600 mt-0.5 shrink-0" />
              <div className="text-[11px] text-amber-800 leading-relaxed">
                현재 접속하신 계정은 소유자(<strong>{OWNER_EMAIL}</strong>)가 아닙니다.
                구글 시트 저장 및 발행 권한은 소유자에게만 부여되어 있으며, 다른 계정은 안전한 읽기 전용으로 열람됩니다.
              </div>
            </div>
          )}

          {/* Error Message */}
          {errorMsg && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg flex items-start gap-2 text-rose-700 text-xs">
              <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Sync Success Box */}
          {syncResult && (
            <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-lg space-y-3">
              <div className="flex items-center gap-2 text-emerald-800 font-semibold text-xs">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Google Sheets 동기화 완료!</span>
              </div>
              <p className="text-[11px] text-emerald-700 leading-relaxed">
                스프레드시트에 <strong>{syncResult.sheetTitle}</strong> 탭이 생성/갱신되었으며, 총{' '}
                <strong>{syncResult.rowsCount}</strong>행의 다거점 PSI 데이터가 성공적으로 기록되었습니다.
              </p>
              <a
                href={syncResult.spreadsheetUrl}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow-xs transition-colors"
              >
                <span>내 Google 스프레드시트 열기</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          )}

          {/* Sync Action Button */}
          <div className="space-y-2">
            <button
              type="button"
              disabled={isSyncing || (Boolean(currentUserEmail) && !isOwner)}
              onClick={handleSyncToSheets}
              className={`w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg font-semibold text-xs text-white transition-all shadow-xs ${
                isSyncing
                  ? 'bg-slate-400 cursor-not-allowed'
                  : Boolean(currentUserEmail) && !isOwner
                  ? 'bg-slate-300 text-slate-500 cursor-not-allowed'
                  : 'bg-emerald-600 hover:bg-emerald-700 active:scale-[0.99]'
              }`}
            >
              {isSyncing ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>{syncStep || 'Google Sheets로 동기화 중...'}</span>
                </>
              ) : (
                <>
                  <RefreshCw className="w-4 h-4" />
                  <span>[ {currentWeek.weekId} ] 주차 데이터 Google Sheets로 동기화</span>
                </>
              )}
            </button>
            <p className="text-[10px] text-slate-500 text-center">
              * 내 Google Drive에 <code>[PSI Flow] 다거점 주차별 생산판매재고 관리</code> 파일이 자동으로 관리됩니다.
            </p>
          </div>

          <div className="pt-3 border-t border-slate-100 flex justify-end">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-1.5 text-xs font-medium text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
            >
              닫기
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
