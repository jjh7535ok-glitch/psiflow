import React, { useState } from 'react';
import {
  X,
  Copy,
  Check,
  Calendar,
  Lock,
  ShieldCheck,
  ExternalLink,
  Download,
  AlertCircle,
  FileSpreadsheet,
} from 'lucide-react';
import { ProductItem, PsiDataStore } from '../types/psi';
import { WeekInfo, createWeeklyShareUrl } from '../utils/weeklyUtils';
import { exportToCsv, downloadFile } from '../utils/psiEngine';

interface WeeklyShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentWeek: WeekInfo;
  products: ProductItem[];
  dateList: string[];
  dataStore: PsiDataStore;
  ownerEmail: string;
  isOwner: boolean;
  onShowToast: (msg: string) => void;
}

export const WeeklyShareModal: React.FC<WeeklyShareModalProps> = ({
  isOpen,
  onClose,
  currentWeek,
  products,
  dateList,
  dataStore,
  ownerEmail,
  isOwner,
  onShowToast,
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  // Generate week-specific immutable read-only link
  const weeklyShareUrl = createWeeklyShareUrl(currentWeek, products, dataStore, ownerEmail);

  const handleCopyLink = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(weeklyShareUrl);
      setCopied(true);
      onShowToast(`[${currentWeek.weekId}] 주차별 읽기 전용 공유 링크가 클립보드에 복사되었습니다!`);
      setTimeout(() => setCopied(false), 2200);
    }
  };

  const handleDownloadWeeklyCsv = () => {
    const csvData = exportToCsv(products, dateList, dataStore);
    downloadFile(csvData, `PSI_${currentWeek.weekId}_Weekly_Report.csv`);
    onShowToast(`[${currentWeek.weekId}] 엑셀 CSV 파일이 다운로드되었습니다.`);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 animate-in fade-in duration-150">
      <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-xl overflow-hidden flex flex-col">
        {/* Modal Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white">
              <Calendar className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white flex items-center gap-2">
                <span>주차별 확정본 공유 및 배포</span>
                <span className="px-2 py-0.5 rounded text-[11px] font-mono bg-blue-500/20 text-blue-300 border border-blue-400/30">
                  {currentWeek.weekId}
                </span>
              </h2>
              <p className="text-[11px] text-slate-400 mt-0.5">
                {currentWeek.weekLabel}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-5 text-xs text-slate-700 overflow-y-auto max-h-[75vh]">
          {/* Governance Notice */}
          <div className="p-3.5 bg-blue-50/70 border border-blue-200 rounded-lg flex items-start gap-3">
            <ShieldCheck className="w-4 h-4 text-blue-600 mt-0.5 shrink-0" />
            <div className="space-y-1">
              <p className="font-semibold text-blue-900">
                소유자 단독 수정·배포 및 안전한 읽기 전용 링크 안내
              </p>
              <p className="text-[11px] text-blue-800 leading-relaxed">
                이 링크를 받은 팀원/거래처는 <strong>읽기 전용(Read-Only)</strong> 상태로 접속되어 원본 데이터를 임의로 수정할 수 없습니다. 
                주차별(W42, W43, W44...)로 내용을 수정한 뒤 각 주차 링크를 발송하시면, 상대방은 주차별 확정 계획을 독립적으로 열람하게 됩니다.
              </p>
            </div>
          </div>

          {/* Share URL Box */}
          <div className="space-y-1.5">
            <label className="text-[11px] font-bold text-slate-700 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <Lock className="w-3.5 h-3.5 text-slate-500" />
                <span>{currentWeek.weekId} 주차별 읽기 전용 접속 링크</span>
              </span>
              <span className="text-[10px] text-slate-500 font-normal">
                소유자: <code className="font-mono">{ownerEmail}</code>
              </span>
            </label>

            <div className="flex items-center gap-2">
              <input
                type="text"
                readOnly
                value={weeklyShareUrl}
                className="flex-1 px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg font-mono text-[11px] text-slate-700 select-all focus:outline-none"
              />
              <button
                type="button"
                onClick={handleCopyLink}
                className={`flex items-center gap-1.5 px-4 py-2 text-xs font-semibold rounded-lg transition-all shrink-0 shadow-xs ${
                  copied
                    ? 'bg-emerald-600 text-white'
                    : 'bg-blue-600 hover:bg-blue-700 text-white'
                }`}
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5" />
                    <span>복사 완료!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>주차 링크 복사</span>
                  </>
                )}
              </button>
            </div>
            <p className="text-[10px] text-slate-500">
              * 링크 복사 후 사내 메신저(카카오톡, 슬랙), 이메일로 전달하여 주차별 계획을 공지하세요.
            </p>
          </div>

          {/* Backup & Offline Options */}
          <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-medium text-slate-600">오프라인 보고용 백업:</span>
              <button
                type="button"
                onClick={handleDownloadWeeklyCsv}
                className="flex items-center gap-1 px-2.5 py-1 text-[11px] font-medium text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 rounded transition-colors"
              >
                <FileSpreadsheet className="w-3.5 h-3.5" />
                <span>{currentWeek.weekId} CSV 다운로드</span>
              </button>
            </div>

            <button
              type="button"
              onClick={onClose}
              className="px-4 py-1.5 text-xs font-medium text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
            >
              닫기
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
