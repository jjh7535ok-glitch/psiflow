import React, { useState, useMemo } from 'react';
import { ProductItem, MonthlyInitialStockRecord } from '../types/psi';
import { Plus, Edit2, Trash2, PackageCheck, Car, Layers, Box, Search, AlertTriangle, X, Settings, Factory, Calendar } from 'lucide-react';
import { ensureProductModels } from '../utils/psiEngine';
import { loadProductionLines } from '../utils/capaEngine';
import { MonthlyInventoryModal } from './MonthlyInventoryModal';

interface ProductMasterViewProps {
  products: ProductItem[];
  currentDateMonth?: string;
  onOpenNewProductModal: () => void;
  onEditProduct: (product: ProductItem) => void;
  onDeleteProduct: (productId: string) => void;
  onSaveMonthlyInventory?: (
    month: string,
    updatedData: Record<string, MonthlyInitialStockRecord>
  ) => void;
  isReadOnly?: boolean;
}

export const ProductMasterView: React.FC<ProductMasterViewProps> = ({
  products,
  currentDateMonth = '2026-10',
  onOpenNewProductModal,
  onEditProduct,
  onDeleteProduct,
  onSaveMonthlyInventory,
  isReadOnly = false,
}) => {
  const [search, setSearch] = useState('');
  const [productToDelete, setProductToDelete] = useState<ProductItem | null>(null);
  const [isMonthlyModalOpen, setIsMonthlyModalOpen] = useState(false);

  const productionLines = useMemo(() => loadProductionLines(products), [products]);

  const sanitizedProducts = products.map((p, idx) => ensureProductModels(p, idx));

  const filtered = sanitizedProducts.filter(
    (p) =>
      p.code.toLowerCase().includes(search.toLowerCase()) ||
      p.name.toLowerCase().includes(search.toLowerCase()) ||
      p.category.toLowerCase().includes(search.toLowerCase()) ||
      p.models.some(
        (m) =>
          m.name.toLowerCase().includes(search.toLowerCase()) ||
          m.customer.toLowerCase().includes(search.toLowerCase()) ||
          m.hubName.toLowerCase().includes(search.toLowerCase())
      )
  );

  const handleConfirmDelete = () => {
    if (productToDelete) {
      onDeleteProduct(productToDelete.id);
      setProductToDelete(null);
    }
  };

  return (
    <div className="flex-1 w-full overflow-y-auto bg-slate-100 p-6 space-y-4">
      <div className="bg-white border border-slate-200 rounded-lg shadow-xs overflow-hidden">
        {/* Table Header Controls */}
        <div className="p-4 border-b border-slate-200 flex flex-wrap items-center justify-between gap-4">
          <div>
            <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <PackageCheck className="w-4 h-4 text-blue-600" />
              <span>차량 부품 품목 마스터 및 차종·출고센터 공급망 관리</span>
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              공장 생산 품목별 고객사 차종, 지정 출고센터, 적입/파레트 기준 및 거점별 안전재고를 통합 관리합니다.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="코드, 품목명, 차종, 센터 검색..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-8 pr-3 py-1.5 w-60 bg-slate-50 border border-slate-200 rounded text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:bg-white"
              />
            </div>

            <button
              type="button"
              onClick={() => setIsMonthlyModalOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 rounded text-xs font-semibold shadow-2xs transition-colors whitespace-nowrap"
            >
              <Calendar className="w-3.5 h-3.5 text-blue-600" />
              <span>월별 기초재고 장부 관리</span>
            </button>

            {!isReadOnly && (
              <button
                type="button"
                onClick={onOpenNewProductModal}
                className="flex items-center gap-1.5 px-3.5 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded text-xs font-semibold shadow-xs transition-colors whitespace-nowrap"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>신규 부품 등록</span>
              </button>
            )}
          </div>
        </div>

        {/* Products Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs divide-y divide-slate-200">
            <thead className="bg-slate-50 text-slate-700 font-semibold border-b border-slate-200">
              <tr>
                <th className="px-4 py-2.5">품목코드</th>
                <th className="px-4 py-2.5">품목명</th>
                <th className="px-4 py-2.5">카테고리</th>
                <th className="px-3 py-2.5 text-center">단위</th>
                <th className="px-4 py-2.5 text-right font-mono">1파레트당 수량</th>
                <th className="px-4 py-2.5 text-right font-mono text-blue-900">
                  [{currentDateMonth ? `${parseInt(currentDateMonth.split('-')[1] || '10', 10)}월` : '당월'}] 공장 기초재고
                </th>
                <th className="px-4 py-2.5">연결된 고객사 차종 및 출고센터 공급망 (거점 기초재고 / 안전재고)</th>
                <th className="px-4 py-2.5 text-center w-24">관리</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-500 text-xs">
                    검색 결과와 일치하는 품목이 없습니다.
                  </td>
                </tr>
              ) : (
                filtered.map((prod) => {
                  const activeMonth = currentDateMonth || '2026-10';
                  const activeFactoryStock =
                    prod.monthlyInitialStocks?.[activeMonth]?.factory ?? prod.factoryInitialStock;

                  return (
                    <tr key={prod.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="px-4 py-3 font-mono font-bold text-blue-700 whitespace-nowrap">
                        {prod.code}
                      </td>
                      <td className="px-4 py-3 font-semibold text-slate-900">
                        <div>{prod.name}</div>
                        <div className="flex items-center gap-2 mt-0.5 text-[11px] text-slate-400 font-normal">
                          <span>박스당 {prod.boxQty} {prod.unit}</span>
                          {(() => {
                            const matchedLine = productionLines.find((l) =>
                              l.productConfigs.some((c) => c.productId === prod.id)
                            );
                            if (!matchedLine) return null;
                            return (
                              <span className="inline-flex items-center gap-1 px-1.5 py-0.2 rounded text-[10px] font-semibold bg-blue-50 text-blue-700 border border-blue-200">
                                <Factory className="w-2.5 h-2.5" />
                                <span>{matchedLine.name.split('(')[0].trim()}</span>
                              </span>
                            );
                          })()}
                        </div>
                      </td>
                      <td className="px-4 py-3 text-slate-600 whitespace-nowrap">
                        <span className="px-2 py-0.5 bg-slate-100 rounded text-[11px] font-medium text-slate-700">
                          {prod.category}
                        </span>
                      </td>
                      <td className="px-3 py-3 text-center text-slate-500 font-medium whitespace-nowrap">
                        {prod.unit}
                      </td>
                      <td className="px-4 py-3 text-right font-mono font-bold text-amber-900 bg-amber-50/30 whitespace-nowrap">
                        {prod.palletQty.toLocaleString()} {prod.unit}
                      </td>
                      <td className="px-4 py-3 text-right font-mono font-bold text-blue-700 bg-blue-50/40 whitespace-nowrap">
                        {activeFactoryStock.toLocaleString()}
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex flex-col gap-1.5">
                          {Array.from(new Set(prod.models.map((m) => m.hubName || '울산 출고센터'))).map((hub) => {
                            const ms = prod.models.filter((m) => (m.hubName || '울산 출고센터') === hub);
                            const hubStock =
                              prod.monthlyInitialStocks?.[activeMonth]?.hubs?.[hub] ??
                              prod.hubs?.[hub]?.initialStock ??
                              ms.reduce((s, m) => s + (Number(m.initialStock) || 0), 0);
                            const hubSafety =
                              prod.hubs?.[hub]?.safetyStock ??
                              ms.reduce((s, m) => s + (Number(m.safetyStock) || 0), 0);
                            return (
                              <div
                                key={hub}
                                className="inline-flex items-center gap-2 px-2.5 py-1 bg-white border border-slate-200 rounded text-[11px] shadow-2xs flex-wrap"
                              >
                                <span className="font-bold text-slate-800">📍 {hub}</span>
                                <span className="text-slate-300">|</span>
                                <div className="flex items-center gap-1">
                                  {ms.map((m) => (
                                    <span
                                      key={m.id}
                                      className="px-1.5 py-0.2 rounded text-[10px] font-semibold bg-blue-50 text-blue-700 border border-blue-200"
                                    >
                                      [{m.customer}] {m.name}
                                    </span>
                                  ))}
                                </div>
                                <span className="text-[10px] text-slate-700 font-mono font-medium ml-auto">
                                  기초재고 <strong className="text-indigo-700">{hubStock.toLocaleString()}</strong> / 안전재고 <strong className="text-emerald-700">{hubSafety.toLocaleString()}</strong> {prod.unit}
                                </span>
                              </div>
                            );
                          })}
                        </div>
                      </td>
                    <td className="px-4 py-3 text-center whitespace-nowrap">
                      {!isReadOnly ? (
                        <div className="flex items-center justify-center gap-1">
                          <button
                            type="button"
                            onClick={() => onEditProduct(prod)}
                            className="p-1.5 text-blue-600 hover:text-blue-800 hover:bg-blue-50 rounded transition-colors"
                            title="품목 및 차종 공급망 설정"
                          >
                            <Settings className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => setProductToDelete(prod)}
                            className="p-1.5 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded transition-colors"
                            title="품목 삭제"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ) : (
                        <span className="text-slate-400 text-[11px]">읽기 전용</span>
                      )}
                    </td>
                  </tr>
                );
              }))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      {productToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-4">
          <div className="bg-white rounded-lg shadow-xl border border-slate-200 max-w-sm w-full p-5 space-y-4 animate-in fade-in zoom-in-95">
            <div className="flex items-center gap-3 text-rose-600">
              <div className="p-2 bg-rose-100 rounded-full">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-bold text-slate-900">품목 삭제 확인</h3>
            </div>
            <p className="text-xs text-slate-600">
              정말로 <strong>[{productToDelete.code}] {productToDelete.name}</strong> 품목과 연결된 모든 차종 공급망 데이터를 삭제하시겠습니까?
            </p>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setProductToDelete(null)}
                className="px-3 py-1.5 text-xs text-slate-600 hover:bg-slate-100 rounded"
              >
                취소
              </button>
              <button
                type="button"
                onClick={handleConfirmDelete}
                className="px-3 py-1.5 text-xs font-semibold bg-rose-600 hover:bg-rose-500 text-white rounded shadow-xs"
              >
                삭제하기
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Monthly Beginning Inventory Ledger Modal */}
      {isMonthlyModalOpen && (
        <MonthlyInventoryModal
          isOpen={isMonthlyModalOpen}
          onClose={() => setIsMonthlyModalOpen(false)}
          products={products}
          currentDateMonth={currentDateMonth}
          onSaveMonthlyInventory={(month, updatedData) => {
            onSaveMonthlyInventory?.(month, updatedData);
            setIsMonthlyModalOpen(false);
          }}
          isReadOnly={isReadOnly}
        />
      )}
    </div>
  );
};
