import { ProductItem, PsiDataStore } from '../types/psi';
import { calculateHubPsi, ensureProductModels } from '../utils/psiEngine';

export interface SyncToSheetsParams {
  accessToken: string;
  weekId: string;
  weekLabel: string;
  products: ProductItem[];
  dateList: string[];
  dataStore: PsiDataStore;
  ownerEmail?: string;
}

export interface SyncResult {
  success: boolean;
  spreadsheetId: string;
  spreadsheetUrl: string;
  sheetTitle: string;
  rowsCount: number;
}

const DEFAULT_SPREADSHEET_TITLE = '[PSI Flow] 다거점 주차별 생산판매재고 관리';

/**
 * Find or create master spreadsheet in Google Drive
 */
async function findOrCreateSpreadsheet(
  accessToken: string,
  title: string = DEFAULT_SPREADSHEET_TITLE
): Promise<{ id: string; url: string }> {
  // 1. Search for existing spreadsheet in Google Drive
  const query = encodeURIComponent(
    `name = '${title.replace(/'/g, "\\'")}' and mimeType = 'application/vnd.google-apps.spreadsheet' and trashed = false`
  );
  const searchRes = await fetch(
    `https://www.googleapis.com/drive/v3/files?q=${query}&fields=files(id,name,webViewLink)`,
    {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    }
  );

  if (searchRes.ok) {
    const searchData = await searchRes.json();
    if (searchData.files && searchData.files.length > 0) {
      const file = searchData.files[0];
      return {
        id: file.id,
        url: file.webViewLink || `https://docs.google.com/spreadsheets/d/${file.id}/edit`,
      };
    }
  }

  // 2. Create new spreadsheet if not found
  const createRes = await fetch('https://sheets.googleapis.com/v4/spreadsheets', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      properties: {
        title,
      },
    }),
  });

  if (!createRes.ok) {
    const errText = await createRes.text();
    throw new Error(`Google 스프레드시트 생성 실패: ${errText}`);
  }

  const createdData = await createRes.json();
  return {
    id: createdData.spreadsheetId,
    url:
      createdData.spreadsheetUrl ||
      `https://docs.google.com/spreadsheets/d/${createdData.spreadsheetId}/edit`,
  };
}

/**
 * Ensure a sheet/tab exists for this week, or create it
 */
async function ensureSheetTab(
  accessToken: string,
  spreadsheetId: string,
  targetTabTitle: string
): Promise<void> {
  const metaRes = await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}?fields=sheets.properties`,
    {
      headers: { Authorization: `Bearer ${accessToken}` },
    }
  );

  if (!metaRes.ok) {
    throw new Error('스프레드시트 탭 정보를 가져오지 못했습니다.');
  }

  const meta = await metaRes.json();
  const existingSheets = meta.sheets || [];
  const tabExists = existingSheets.some(
    (s: any) => s.properties?.title === targetTabTitle
  );

  if (!tabExists) {
    // Add new sheet tab
    const addSheetRes = await fetch(
      `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}:batchUpdate`,
      {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          requests: [
            {
              addSheet: {
                properties: {
                  title: targetTabTitle,
                  gridProperties: {
                    rowCount: 150,
                    columnCount: 30,
                  },
                },
              },
            },
          ],
        }),
      }
    );

    if (!addSheetRes.ok) {
      console.warn('탭 추가 중 오류 발생 (기존 탭 사용 시도):', await addSheetRes.text());
    }
  }
}

/**
 * Build 2D rows for the Google Sheet tab
 */
function buildSheetData(
  weekLabel: string,
  products: ProductItem[],
  dateList: string[],
  dataStore: PsiDataStore,
  ownerEmail: string
): (string | number)[][] {
  const rows: (string | number)[][] = [];

  // Title header
  rows.push(['[PSI Flow] 다거점 생산·판매·재고 관리 대시보드']);
  rows.push([
    '조회 주차:',
    weekLabel,
    '동기화 일시:',
    new Date().toLocaleString('ko-KR'),
    '소유자(관리자):',
    ownerEmail,
  ]);
  rows.push([]);

  // Column Headers
  const headerRow: (string | number)[] = [
    '품목코드',
    '품목명',
    '계층구분',
    '고객사',
    '차종/출고센터',
    '단위',
    '지표명',
    ...dateList,
    '기간누적/기말',
  ];
  rows.push(headerRow);

  const sum = (arr: number[]) => arr.reduce((a, b) => a + b, 0);

  // Rows per product
  products.forEach((rawProd) => {
    const psiResult = calculateHubPsi(rawProd, dateList, dataStore[rawProd.id] || {});
    const prod = psiResult.days.length > 0 ? ensureProductModels(rawProd) : rawProd;
    const days = psiResult.days;
    const baseInfo = [
      prod.code,
      prod.name,
      '공장생산',
      '자체공장',
      '아산 생산라인',
      prod.unit || 'EA',
    ];

    // 1. 공장 생산계획
    const prodPlans = days.map((d) => d.prodPlan);
    rows.push([
      ...baseInfo,
      '생산계획',
      ...prodPlans,
      sum(prodPlans),
    ]);

    // 2. 공장 생산실적
    const prodActuals = days.map((d) => d.prodActual);
    rows.push([
      ...baseInfo,
      '생산실적',
      ...prodActuals,
      `${sum(prodActuals)} (${psiResult.summary.prodAttainment}%)`,
    ]);

    // 3. 공장 총출하
    const totalAllocs = days.map((d) => d.totalFactoryAlloc);
    rows.push([
      ...baseInfo,
      '공장총출하',
      ...totalAllocs,
      sum(totalAllocs),
    ]);

    // 4. 공장 잔여재고
    const factoryStocks = days.map((d) => d.factoryEndingStock);
    const lastFactoryStock = factoryStocks[factoryStocks.length - 1] ?? 0;
    rows.push([
      ...baseInfo,
      '공장보유재고',
      ...factoryStocks,
      `기말: ${lastFactoryStock}`,
    ]);

    // 차종별 지표
    prod.models.forEach((m) => {
      const modelInfo = [
        prod.code,
        prod.name,
        '차종별',
        m.customer,
        `${m.name} (${m.hubName})`,
        prod.unit || 'EA',
      ];

      // 판매계획
      const salesPlans = days.map((d) => d.models[m.id]?.salesPlan ?? 0);
      rows.push([
        ...modelInfo,
        '판매계획(소요량)',
        ...salesPlans,
        sum(salesPlans),
      ]);

      // 판매실적
      const salesActuals = days.map((d) => d.models[m.id]?.salesActual ?? 0);
      rows.push([
        ...modelInfo,
        '판매실적',
        ...salesActuals,
        `${sum(salesActuals)} (${psiResult.summary.models[m.id]?.salesAttainment ?? 0}%)`,
      ]);

      // 입고계획
      const inboundPlans = days.map((d) => d.models[m.id]?.inboundPlan ?? 0);
      rows.push([
        ...modelInfo,
        '입고계획(배분)',
        ...inboundPlans,
        sum(inboundPlans),
      ]);

      // 입고실적
      const inboundActuals = days.map((d) => d.models[m.id]?.inboundActual ?? 0);
      rows.push([
        ...modelInfo,
        '입고실적',
        ...inboundActuals,
        `${sum(inboundActuals)} (${psiResult.summary.models[m.id]?.inboundAttainment ?? 0}%)`,
      ]);

      // 거점기말재고
      const endingStocks = days.map((d) => d.models[m.id]?.endingStock ?? 0);
      const lastStock = endingStocks[endingStocks.length - 1] ?? 0;
      rows.push([
        ...modelInfo,
        '거점기말재고',
        ...endingStocks,
        `기말: ${lastStock}`,
      ]);
    });

    // 통합 롤업 지표
    const rollupInfo = [
      prod.code,
      prod.name,
      '통합롤업',
      '전체고객사',
      '전체출고센터',
      prod.unit || 'EA',
    ];

    const pipelineStocks = days.map((d) => d.totalPipelineStock);
    const lastPipelineStock = pipelineStocks[pipelineStocks.length - 1] ?? 0;
    rows.push([
      ...rollupInfo,
      '전체물류총재고',
      ...pipelineStocks,
      `기말: ${lastPipelineStock}`,
    ]);

    // Divider row
    rows.push([]);
  });

  return rows;
}

/**
 * Export and Synchronize current weekly PSI plan to Google Sheets
 */
export async function syncWeeklyPlanToGoogleSheets(
  params: SyncToSheetsParams
): Promise<SyncResult> {
  const {
    accessToken,
    weekId,
    weekLabel,
    products,
    dateList,
    dataStore,
    ownerEmail = 'jjh7535ok@gmail.com',
  } = params;

  // 1. Locate or create spreadsheet file in user's Drive
  const sheetFile = await findOrCreateSpreadsheet(accessToken, DEFAULT_SPREADSHEET_TITLE);

  // 2. Tab name for this week
  const tabName = weekId.replace(/-/g, '_');
  await ensureSheetTab(accessToken, sheetFile.id, tabName);

  // 3. Prepare rows data
  const rows = buildSheetData(weekLabel, products, dateList, dataStore, ownerEmail);

  // 4. Overwrite tab content
  const writeUrl = `https://sheets.googleapis.com/v4/spreadsheets/${sheetFile.id}/values/'${encodeURIComponent(
    tabName
  )}'!A1?valueInputOption=USER_ENTERED`;

  const writeRes = await fetch(writeUrl, {
    method: 'PUT',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      range: `'${tabName}'!A1`,
      majorDimension: 'ROWS',
      values: rows,
    }),
  });

  if (!writeRes.ok) {
    const errText = await writeRes.text();
    throw new Error(`Google Sheets 데이터 작성 실패: ${errText}`);
  }

  return {
    success: true,
    spreadsheetId: sheetFile.id,
    spreadsheetUrl: sheetFile.url,
    sheetTitle: tabName,
    rowsCount: rows.length,
  };
}
