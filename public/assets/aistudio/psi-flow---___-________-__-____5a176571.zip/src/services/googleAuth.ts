import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getAuth,
  signInWithPopup,
  signOut,
  GoogleAuthProvider,
  onAuthStateChanged,
  User,
} from 'firebase/auth';
import firebaseConfig from '../../firebase-applet-config.json';

// Designated owner email for this application
export const OWNER_EMAIL = 'jjh7535ok@gmail.com';

// Initialize Firebase App singleton safely
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
export const auth = getAuth(app);

const provider = new GoogleAuthProvider();
// Google Workspace Scopes
provider.addScope('https://www.googleapis.com/auth/drive.file');
provider.addScope('https://www.googleapis.com/auth/spreadsheets');

let isSigningIn = false;
let cachedAccessToken: string | null = null;

/**
 * Initialize auth listener.
 */
export const initAuth = (
  onAuthSuccess?: (user: User, token: string, isOwner: boolean) => void,
  onAuthFailure?: () => void
) => {
  return onAuthStateChanged(auth, async (user: User | null) => {
    if (user) {
      const isOwner = user.email?.toLowerCase() === OWNER_EMAIL.toLowerCase();
      if (cachedAccessToken) {
        if (onAuthSuccess) onAuthSuccess(user, cachedAccessToken, isOwner);
      } else if (!isSigningIn) {
        // Token will be acquired upon sign-in popup
        if (onAuthSuccess && cachedAccessToken) {
          onAuthSuccess(user, cachedAccessToken, isOwner);
        } else if (onAuthFailure) {
          onAuthFailure();
        }
      }
    } else {
      cachedAccessToken = null;
      if (onAuthFailure) onAuthFailure();
    }
  });
};

/**
 * Perform Google Sign-in popup and cache access token in memory.
 */
export const googleSignIn = async (): Promise<{
  user: User;
  accessToken: string;
  isOwner: boolean;
} | null> => {
  try {
    isSigningIn = true;
    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    if (!credential?.accessToken) {
      throw new Error('Google OAuth 액세스 토큰을 획득하지 못했습니다.');
    }

    cachedAccessToken = credential.accessToken;
    const isOwner = result.user.email?.toLowerCase() === OWNER_EMAIL.toLowerCase();
    return {
      user: result.user,
      accessToken: cachedAccessToken,
      isOwner,
    };
  } catch (error: any) {
    console.error('Sign in error:', error);
    throw error;
  } finally {
    isSigningIn = false;
  }
};

/**
 * Return current in-memory access token.
 */
export const getAccessToken = async (): Promise<string | null> => {
  return cachedAccessToken;
};

/**
 * Sign out and clear in-memory token.
 */
export const googleSignOut = async (): Promise<void> => {
  await signOut(auth);
  cachedAccessToken = null;
};

/**
 * Check if a given user is the designated system owner.
 */
export const checkIsOwner = (user: User | null): boolean => {
  if (!user || !user.email) return false;
  return user.email.toLowerCase() === OWNER_EMAIL.toLowerCase();
};
