import express from 'express';
import { createServer as createViteServer } from 'vite';
import fs from 'fs';
import path from 'path';

async function startServer() {
  const app = express();
  const port = parseInt(process.env.PORT || '3000', 10);

  app.use(express.json());

  // Persistent access logs file
  const LOGS_FILE = path.resolve(process.cwd(), '.access_logs.json');

  function loadLogs() {
    try {
      if (fs.existsSync(LOGS_FILE)) {
        const raw = fs.readFileSync(LOGS_FILE, 'utf-8');
        return JSON.parse(raw);
      }
    } catch {
      // ignore
    }
    return [];
  }

  function saveLogs(logs: unknown[]) {
    try {
      fs.writeFileSync(LOGS_FILE, JSON.stringify(logs, null, 2), 'utf-8');
    } catch (err) {
      console.error('Failed to write access logs:', err);
    }
  }

  let accessLogs: Array<{
    id: string;
    timestamp: string;
    formattedTime: string;
    weekId: string;
    weekLabel: string;
    viewerId: string;
    ip?: string;
    deviceType: string;
    browser: string;
    os: string;
    screenResolution?: string;
    userAgent?: string;
    isOwnerView?: boolean;
  }> = loadLogs();

  // API 1: Silent access log recording
  app.post('/api/access-logs', (req, res) => {
    try {
      const body = req.body || {};
      const clientIp =
        (req.headers['x-forwarded-for'] as string) ||
        req.socket.remoteAddress ||
        '127.0.0.1';

      const entry = {
        id: 'log_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7),
        timestamp: body.timestamp || new Date().toISOString(),
        formattedTime: body.formattedTime || new Date().toLocaleString(),
        weekId: body.weekId || '미지정',
        weekLabel: body.weekLabel || '미지정',
        viewerId: body.viewerId || 'anon',
        ip: String(clientIp).split(',')[0].trim(),
        deviceType: body.deviceType || 'Desktop',
        browser: body.browser || 'Browser',
        os: body.os || 'OS',
        screenResolution: body.screenResolution || '',
        userAgent: body.userAgent || (req.headers['user-agent'] as string) || '',
        isOwnerView: Boolean(body.isOwnerView),
      };

      // Add to beginning of array
      accessLogs.unshift(entry);
      // Keep up to 1000 latest entries
      if (accessLogs.length > 1000) {
        accessLogs = accessLogs.slice(0, 1000);
      }

      saveLogs(accessLogs);
      res.json({ ok: true, count: accessLogs.length });
    } catch (err) {
      console.error('Error logging access:', err);
      res.status(500).json({ error: 'Failed to record log' });
    }
  });

  // API 2: Fetch access logs (for owner inspection)
  app.get('/api/access-logs', (_req, res) => {
    res.json({ logs: accessLogs });
  });

  // API 3: Clear logs (for owner)
  app.delete('/api/access-logs', (_req, res) => {
    accessLogs = [];
    saveLogs([]);
    res.json({ ok: true });
  });

  // Vite middleware in dev or static files in production
  const isProd = process.env.NODE_ENV === 'production';
  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`[PSI Server] Running at http://0.0.0.0:${port}`);
  });
}

startServer().catch((err) => {
  console.error('[PSI Server] Failed to start:', err);
  process.exit(1);
});
