import React, { useState, useEffect, useMemo } from 'react';
import { ProductItem, PsiDataStore, DailyHubRecord, MonthlyInitialStockRecord } from './types/psi';
import {
  INITIAL_PRODUCTS,
  generateDateRange,
  generateDateRangeFromStart,
  generateInitialRecords,
  ensureDatesInDataStore,
  exportToCsv,
  downloadFile,
  forwardFillModelField,
  batchForwardFillPlans,
  ensureProductModels,
  migrateLegacyDataStore,
} from './utils/psiEngine';
import {
  WeekInfo,
  getISOWeekInfo,
  generateWeeklyOptions,
} from './utils/weeklyUtils';
import {
  fetchRemoteWorkspace,
  saveRemoteWorkspace,
  subscribeToRemoteWorkspace,
  testFirestoreConnection,
  createRevisionSnapshot,
  fetchRevisionList,
  fetchRevisionById,
  PublishedRevision,
  RevisionSummary,
} from './services/workspaceSync';
import {
  initAuth,
  googleSignIn,
  googleSignOut,
  OWNER_EMAIL,
  getSavedAuthEmail,
} from './services/googleAuth';
import { TopBar } from './components/TopBar';
import { FilterToolbar } from './components/FilterToolbar';
import { MatrixGrid } from './components/MatrixGrid';
import { TrendAnalytics } from './components/TrendAnalytics';
import { MasterDataView } from './components/MasterDataView';
import { ProductModal } from './components/ProductModal';
import { WeeklyShareModal } from './components/WeeklyShareModal';
import { PublishRevisionModal } from './components/PublishRevisionModal';
import { RevisionNoticeModal } from './components/RevisionNoticeModal';
import { ForwardFillModal } from './components/ForwardFillModal';
import { LineCapaModal } from './components/LineCapaModal';
import { AccessLogModal } from './components/AccessLogModal';
import { ReplenishmentSummaryBar } from './components/ReplenishmentSummaryBar';
import { ReplenishmentDiffModal } from './components/ReplenishmentDiffModal';
import {
  runReplenishmentSimulation,
  applyRecommendationsToDataStore,
  ReplenishmentRecommendation,
} from './services/replenishmentEngine';
import { recordAccessLogSilently } from './services/accessLogService';
import { HubMasterItem, CustomerMasterItem, CategoryMasterItem } from './types/masterData';
import {
  loadHubMasters,
  saveHubMasters,
  loadCustomerMasters,
  saveCustomerMasters,
  loadCategoryMasters,
  saveCategoryMasters,
  INITIAL_HUBS,
  INITIAL_CUSTOMERS,
  INITIAL_CATEGORIES,
} from './utils/masterDataEngine';
import {
  STORAGE_KEY_LINES,
  STORAGE_KEY_SHIFT_RULES,
  loadProductionLines,
  DEFAULT_SHIFT_RULES,
  saveShiftRules,
  ShiftScheduleRules,
} from './utils/capaEngine';
import { CheckCircle2, Info, RotateCcw } from 'lucide-react';

const STORAGE_KEY_PRODUCTS = 'psi_flow_products_v3';
const STORAGE_KEY_DATA = 'psi_flow_datastore_v3';

export default function App() {
  // Navigation Tab
  const [currentTab, setCurrentTab] = useState<'matrix' | 'analytics' | 'products'>('matrix');

  // Current Working Week: Always based on real date (automatically advances each week)
  const [currentWeek, setCurrentWeek] = useState<WeekInfo>(() => getISOWeekInfo());
  const availableWeeks = useMemo(() => generateWeeklyOptions(), []);

  // Start Date for Date Navigation (1주일 집중 뷰: 해당 주차의 월요일 시작)
  const [startDateStr, setStartDateStr] = useState<string>(() => {
    return getISOWeekInfo().startDateStr;
  });

  // Days Range: Default 7 days (1주일 집중 뷰 - 100% 브라우저 배율 최적화)
  const [daysRange, setDaysRange] = useState<number>(7);
  const dateList = useMemo(
    () => generateDateRangeFromStart(startDateStr, daysRange),
    [startDateStr, daysRange]
  );

  // Known owner check from previous session
  const savedEmail = getSavedAuthEmail();

  // Ownership & Permission State: Always authorized for the creator
  const [currentUserEmail, setCurrentUserEmail] = useState<string | null>(savedEmail);
  const [isOwner, setIsOwner] = useState<boolean>(true);

  // Products State with localStorage and Cloud Firestore fallback
  const [products, setProducts] = useState<ProductItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_PRODUCTS);
      if (saved) {
        const parsed: ProductItem[] = JSON.parse(saved);
        return parsed.map((p, idx) => ensureProductModels(p, idx));
      }
    } catch {
      // ignore
    }
    return INITIAL_PRODUCTS;
  });

  // Daily Records Store with localStorage and Cloud Firestore fallback
  const [dataStore, setDataStore] = useState<PsiDataStore>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_DATA);
      if (saved) return migrateLegacyDataStore(JSON.parse(saved), INITIAL_PRODUCTS);
    } catch {
      // ignore
    }
    return generateInitialRecords(INITIAL_PRODUCTS, generateDateRange(14, 2));
  });

  // Filter & Search States (4대 핵심 드릴다운 필터: 품목, 카테고리, 차종, 거점)
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedProductId, setSelectedProductId] = useState('ALL');
  const [selectedCategory, setSelectedCategory] = useState('ALL');
  const [selectedVehicleModel, setSelectedVehicleModel] = useState('ALL');
  const [selectedHub, setSelectedHub] = useState('ALL');

  // Accordion Expand States
  const [expandedProductIds, setExpandedProductIds] = useState<Record<string, boolean>>(() => {
    const map: Record<string, boolean> = {};
    INITIAL_PRODUCTS.forEach((p) => {
      map[p.id] = true;
    });
    return map;
  });
  const [allExpanded, setAllExpanded] = useState<boolean>(true);

  // Modals
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);
  const [productToEdit, setProductToEdit] = useState<ProductItem | null>(null);
  const [isResetConfirmOpen, setIsResetConfirmOpen] = useState(false);
  const [isWeeklyShareModalOpen, setIsWeeklyShareModalOpen] = useState(false);
  const [isForwardFillModalOpen, setIsForwardFillModalOpen] = useState(false);
  const [forwardFillProductId, setForwardFillProductId] = useState<string>('ALL');
  const [isLineCapaModalOpen, setIsLineCapaModalOpen] = useState(false);
  const [isAccessLogModalOpen, setIsAccessLogModalOpen] = useState(false);

  // Baseline Revision States (SCM Option 1)
  const [activeRevision, setActiveRevision] = useState<PublishedRevision | null>(null);
  const [revisionList, setRevisionList] = useState<RevisionSummary[]>([]);
  const [isPublishModalOpen, setIsPublishModalOpen] = useState(false);
  const [isNoticeModalOpen, setIsNoticeModalOpen] = useState(false);

  // Replenishment Simulation & Undo & Diff Modal State
  const [undoDataStore, setUndoDataStore] = useState<PsiDataStore | null>(null);
  const [isDiffModalOpen, setIsDiffModalOpen] = useState(false);
  const [diffTargetRecs, setDiffTargetRecs] = useState<ReplenishmentRecommendation[]>([]);

  // Master Data States (MDM)
  const [hubMasters, setHubMasters] = useState<HubMasterItem[]>(() => loadHubMasters());
  const [customerMasters, setCustomerMasters] = useState<CustomerMasterItem[]>(() => loadCustomerMasters());
  const [categoryMasters, setCategoryMasters] = useState<CategoryMasterItem[]>(() => loadCategoryMasters());

  // Helper to load shift rules
  const loadShiftRules = (): ShiftScheduleRules => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_SHIFT_RULES);
      if (saved) return JSON.parse(saved);
    } catch {}
    return DEFAULT_SHIFT_RULES;
  };

  // Toast Notification
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3000);
  };

  // Mount effect: Check URL parameter ?rev=... for frozen baseline view,
  // or auto-load latest published baseline if anonymous visitor visits without ?rev=
  useEffect(() => {
    const checkUrlRevision = async () => {
      if (typeof window === 'undefined') return;
      const urlParams = new URLSearchParams(window.location.search);
      const revParam = urlParams.get('rev');

      let targetRev: PublishedRevision | null = null;
      if (revParam) {
        try {
          targetRev = await fetchRevisionById(revParam);
        } catch (err) {
          console.error('Failed to load revision from URL query param:', err);
        }
      } else {
        // If no ?rev= param is present, check if this is an anonymous visitor (not owner session)
        const isKnownOwner = localStorage.getItem('psi_auth_user_email');
        if (!isKnownOwner) {
          try {
            // Find latest published revision across all weeks or current week
            const revs = await fetchRevisionList();
            if (revs && revs.length > 0) {
              targetRev = await fetchRevisionById(revs[0].id);
            }
          } catch (err) {
            console.warn('Auto-fallback to latest revision skipped:', err);
          }
        }
      }

      if (targetRev) {
        setActiveRevision(targetRev);
        // Check if user chose "오늘 하루 그만보기"
        const todayStr = new Date().toISOString().slice(0, 10);
        const isHidden = localStorage.getItem(`psi_hide_notice_${targetRev.id}_${todayStr}`);
        if (!isHidden) {
          setIsNoticeModalOpen(true);
        }
      }
    };
    checkUrlRevision();
  }, []);

  // Fetch revisions list when currentWeek changes
  const refreshRevisionList = async (weekId = currentWeek.weekId) => {
    try {
      const list = await fetchRevisionList(weekId);
      setRevisionList(list);
    } catch (err) {
      console.error('Failed to fetch revision list:', err);
    }
  };

  useEffect(() => {
    refreshRevisionList(currentWeek.weekId);
  }, [currentWeek.weekId]);

  // Mount effect: Clear any old snapshot URL hashes and setup auth & access log
  useEffect(() => {
    if (typeof window !== 'undefined' && window.location.hash) {
      window.history.replaceState(null, '', window.location.pathname);
    }

    const unsubscribe = initAuth(
      (user, _token, isOwnerResult) => {
        setCurrentUserEmail(user.email || null);
        setIsOwner(isOwnerResult);
        if (isOwnerResult) {
          loadWorkspaceFromRemote(false);
        }
      },
      () => {
        // Not signed in; default owner mode remains active
      }
    );

    recordAccessLogSilently(currentWeek.weekId, currentWeek.weekLabel, isOwner);

    return () => unsubscribe();
  }, [currentWeek.weekId, currentWeek.weekLabel, isOwner]);

  // Cloud Sync & Workspace State
  const [isWorkspaceLoaded, setIsWorkspaceLoaded] = useState<boolean>(false);
  const [syncStatus, setSyncStatus] = useState<'idle' | 'saving' | 'saved' | 'error'>('idle');
  const [lastSavedTime, setLastSavedTime] = useState<string | null>(null);

  // Load persistent workspace from Cloud Firestore with server fallback
  const loadWorkspaceFromRemote = async (forceNotice = false) => {
    try {
      const remoteData = await fetchRemoteWorkspace();
      if (remoteData) {
        let activeProds = products;
        if (Array.isArray(remoteData.products) && remoteData.products.length > 0) {
          activeProds = remoteData.products.map((p, idx) => ensureProductModels(p, idx));
          setProducts(activeProds);
          try {
            localStorage.setItem(STORAGE_KEY_PRODUCTS, JSON.stringify(activeProds));
          } catch {}
        }
        if (remoteData.dataStore && Object.keys(remoteData.dataStore).length > 0) {
          const migratedStore = migrateLegacyDataStore(remoteData.dataStore, activeProds);
          setDataStore(migratedStore);
          try {
            localStorage.setItem(STORAGE_KEY_DATA, JSON.stringify(migratedStore));
          } catch {}
        }
        if (Array.isArray(remoteData.hubs) && remoteData.hubs.length > 0) {
          setHubMasters(remoteData.hubs);
          saveHubMasters(remoteData.hubs);
        }
        if (Array.isArray(remoteData.customers) && remoteData.customers.length > 0) {
          setCustomerMasters(remoteData.customers);
          saveCustomerMasters(remoteData.customers);
        }
        if (Array.isArray(remoteData.categories) && remoteData.categories.length > 0) {
          setCategoryMasters(remoteData.categories);
          saveCategoryMasters(remoteData.categories);
        }
        const timeStr = remoteData.updatedAt
          ? new Date(remoteData.updatedAt).toLocaleTimeString()
          : new Date().toLocaleTimeString();
        setLastSavedTime(timeStr);
        setSyncStatus('saved');
        if (forceNotice) {
          showToast(`☁️ [${timeStr}] 클라우드 최신 품목 마스터 및 계획 데이터를 동기화했습니다.`);
        }
      }
    } catch (err) {
      console.warn('Could not load remote workspace:', err);
    } finally {
      setIsWorkspaceLoaded(true);
    }
  };

  // Mount effect: Fetch remote workspace once
  useEffect(() => {
    loadWorkspaceFromRemote(false);
  }, []);

  // Real-time listener: Receive changes if edited on another machine (e.g., PC <-> Laptop)
  useEffect(() => {
    if (!isWorkspaceLoaded) return;
    const unsub = subscribeToRemoteWorkspace((remoteData) => {
      if (remoteData.products && remoteData.products.length > 0) {
        const activeProds = remoteData.products.map((p, idx) => ensureProductModels(p, idx));
        setProducts(activeProds);
        try {
          localStorage.setItem(STORAGE_KEY_PRODUCTS, JSON.stringify(activeProds));
        } catch {}
        if (remoteData.dataStore) {
          setDataStore(migrateLegacyDataStore(remoteData.dataStore, activeProds));
        }
      }
      if (remoteData.hubs && remoteData.hubs.length > 0) {
        setHubMasters(remoteData.hubs);
      }
      if (remoteData.customers && remoteData.customers.length > 0) {
        setCustomerMasters(remoteData.customers);
      }
      if (remoteData.categories && remoteData.categories.length > 0) {
        setCategoryMasters(remoteData.categories);
      }
      const timeStr = remoteData.updatedAt
        ? new Date(remoteData.updatedAt).toLocaleTimeString()
        : new Date().toLocaleTimeString();
      setLastSavedTime(timeStr);
      setSyncStatus('saved');
    });

    return () => unsub();
  }, [isWorkspaceLoaded]);

  // Sync to Cloud Firestore, Server, and localStorage (Debounced)
  useEffect(() => {
    // CRITICAL GUARD: Never save until the initial remote load has fully succeeded!
    // This prevents default laptop state from overwriting PC changes.
    if (!isWorkspaceLoaded) return;
    if (!isOwner) return;

    setSyncStatus('saving');
    const timer = setTimeout(async () => {
      try {
        const result = await saveRemoteWorkspace({
          products,
          dataStore,
          hubs: hubMasters,
          customers: customerMasters,
          categories: categoryMasters,
          updatedBy: currentUserEmail || OWNER_EMAIL,
        });

        if (result.ok) {
          setSyncStatus('saved');
          setLastSavedTime(new Date().toLocaleTimeString());
          try {
            localStorage.setItem(STORAGE_KEY_PRODUCTS, JSON.stringify(products));
            localStorage.setItem(STORAGE_KEY_DATA, JSON.stringify(dataStore));
            saveHubMasters(hubMasters);
            saveCustomerMasters(customerMasters);
            saveCategoryMasters(categoryMasters);
          } catch {}
        } else {
          setSyncStatus('error');
        }
      } catch (err) {
        console.error('Failed to sync to remote:', err);
        setSyncStatus('error');
      }
    }, 800);

    return () => clearTimeout(timer);
  }, [products, dataStore, hubMasters, customerMasters, categoryMasters, isOwner, isWorkspaceLoaded, currentUserEmail]);

  // Manual Save Trigger
  const handleManualSave = async () => {
    if (!isOwner) {
      showToast('🔒 수정 권한이 없습니다. 상단에서 소유자 로그인이 필요합니다.');
      return;
    }
    setSyncStatus('saving');
    try {
      const result = await saveRemoteWorkspace({
        products,
        dataStore,
        hubs: hubMasters,
        customers: customerMasters,
        categories: categoryMasters,
        updatedBy: currentUserEmail || OWNER_EMAIL,
      });
      if (result.ok) {
        const timeStr = new Date().toLocaleTimeString();
        setSyncStatus('saved');
        setLastSavedTime(timeStr);
        try {
          localStorage.setItem(STORAGE_KEY_PRODUCTS, JSON.stringify(products));
          localStorage.setItem(STORAGE_KEY_DATA, JSON.stringify(dataStore));
          saveHubMasters(hubMasters);
          saveCustomerMasters(customerMasters);
          saveCategoryMasters(categoryMasters);
        } catch {}
        showToast(`☁️ [${timeStr}] 품목 마스터 및 모든 계획이 클라우드에 안전하게 영구 저장되었습니다.`);
      } else {
        setSyncStatus('error');
        showToast('⚠️ 클라우드 저장 중 통신 오류가 발생했습니다.');
      }
    } catch (err) {
      setSyncStatus('error');
      showToast('⚠️ 클라우드 저장 실패');
    }
  };

  // Manual Reload Trigger
  const handleReloadRemote = async () => {
    await loadWorkspaceFromRemote(true);
  };

  // Week Navigation Handlers
  const handlePrevWeek = () => {
    const idx = availableWeeks.findIndex((w) => w.weekId === currentWeek.weekId);
    if (idx > 0) {
      const targetWeek = availableWeeks[idx - 1];
      setCurrentWeek(targetWeek);
      setStartDateStr(targetWeek.startDateStr);
    } else {
      const d = new Date(currentWeek.startDateStr);
      d.setDate(d.getDate() - 7);
      const targetWeek = getISOWeekInfo(d);
      setCurrentWeek(targetWeek);
      setStartDateStr(targetWeek.startDateStr);
    }
  };

  const handleNextWeek = () => {
    const idx = availableWeeks.findIndex((w) => w.weekId === currentWeek.weekId);
    if (idx >= 0 && idx < availableWeeks.length - 1) {
      const targetWeek = availableWeeks[idx + 1];
      setCurrentWeek(targetWeek);
      setStartDateStr(targetWeek.startDateStr);
    } else {
      const d = new Date(currentWeek.startDateStr);
      d.setDate(d.getDate() + 7);
      const targetWeek = getISOWeekInfo(d);
      setCurrentWeek(targetWeek);
      setStartDateStr(targetWeek.startDateStr);
    }
  };

  // Timeline Navigation Handlers (과거/미래 자유 이동)
  const handlePrevPeriod = () => {
    const [y, m, d] = startDateStr.split('-').map(Number);
    const dateObj = new Date(y, m - 1, d);
    dateObj.setDate(dateObj.getDate() - (daysRange === 7 ? 7 : daysRange === 14 ? 7 : 14));
    const nextStr = `${dateObj.getFullYear()}-${String(dateObj.getMonth() + 1).padStart(2, '0')}-${String(dateObj.getDate()).padStart(2, '0')}`;
    setStartDateStr(nextStr);
    setCurrentWeek(getISOWeekInfo(dateObj));
  };

  const handleNextPeriod = () => {
    const [y, m, d] = startDateStr.split('-').map(Number);
    const dateObj = new Date(y, m - 1, d);
    dateObj.setDate(dateObj.getDate() + (daysRange === 7 ? 7 : daysRange === 14 ? 7 : 14));
    const nextStr = `${dateObj.getFullYear()}-${String(dateObj.getMonth() + 1).padStart(2, '0')}-${String(dateObj.getDate()).padStart(2, '0')}`;
    setStartDateStr(nextStr);
    setCurrentWeek(getISOWeekInfo(dateObj));
  };

  const handleJumpToday = () => {
    const todayWeek = getISOWeekInfo();
    setCurrentWeek(todayWeek);
    setStartDateStr(todayWeek.startDateStr);
  };

  const handleStartDateChange = (val: string) => {
    if (val) setStartDateStr(val);
  };

  // 날짜 범위가 과거/미래로 확장되었을 때, 신규 날짜에 대한 기본 PSI 레코드를 자동 보완
  useEffect(() => {
    setDataStore((prevStore) => ensureDatesInDataStore(prevStore, products, dateList));
  }, [dateList, products]);

  // In-cell Forward Fill Handler
  const handleForwardFillField = (
    productId: string,
    modelId: string | null,
    field: 'prodPlan' | 'prodActual' | 'salesPlan' | 'salesActual' | 'inboundPlan' | 'inboundActual',
    fromDateStr: string,
    value: number,
    keepWeekendZero: boolean
  ) => {
    if (!isOwner) return;
    setDataStore((prev) =>
      forwardFillModelField(prev, productId, modelId, field, fromDateStr, value, keepWeekendZero, dateList)
    );
    showToast(`기준일 [${fromDateStr}] 이후 날짜로 값이 일괄 전개되었습니다.`);
  };

  // Batch Forward Fill Plans Handler (Modal)
  const handleBatchForwardFillPlans = (params: {
    productIds: string[];
    startDateStr: string;
    prodPlan?: number;
    modelPlans: Record<string, number>;
    syncInbound: boolean;
    keepWeekendZero: boolean;
  }) => {
    if (!isOwner) return;
    setDataStore((prev) => batchForwardFillPlans(prev, products, { ...params, dateList }));
    showToast('⚡ 고객사 차종별 오더/소요량 계획이 성공적으로 일괄 전개되었습니다! (공장 생산계획은 라인 CAPA 설정을 유지합니다)');
  };

  // When viewing a frozen baseline revision (Option 1), display snapshot datasets and lock editing
  const displayProducts = useMemo(() => {
    return activeRevision ? activeRevision.products : products;
  }, [activeRevision, products]);

  const displayDataStore = useMemo(() => {
    return activeRevision ? activeRevision.dataStore : dataStore;
  }, [activeRevision, dataStore]);

  const displayHubMasters = useMemo(() => {
    return activeRevision?.hubs && activeRevision.hubs.length > 0 ? activeRevision.hubs : hubMasters;
  }, [activeRevision, hubMasters]);

  const displayCustomerMasters = useMemo(() => {
    return activeRevision?.customers && activeRevision.customers.length > 0
      ? activeRevision.customers
      : customerMasters;
  }, [activeRevision, customerMasters]);

  const displayCategoryMasters = useMemo(() => {
    return activeRevision?.categories && activeRevision.categories.length > 0
      ? activeRevision.categories
      : categoryMasters;
  }, [activeRevision, categoryMasters]);

  // Categories list
  const categories = useMemo(() => {
    const set = new Set<string>();
    displayCategoryMasters.forEach((c) => set.add(c.name));
    displayProducts.forEach((p) => {
      if (p.category) set.add(p.category);
    });
    return Array.from(set);
  }, [displayCategoryMasters, displayProducts]);

  // Vehicle Models list
  const vehicleModels = useMemo(() => {
    const set = new Set<string>();
    displayProducts.forEach((p) => {
      p.models.forEach((m) => {
        if (m.name) set.add(m.name);
      });
    });
    return Array.from(set);
  }, [displayProducts]);

  // Hubs list from all product models & hubMasters
  const hubs = useMemo(() => {
    const set = new Set<string>();
    displayHubMasters.forEach((h) => set.add(h.name));
    displayProducts.forEach((p) => {
      p.models.forEach((m) => {
        if (m.hubName) set.add(m.hubName);
      });
    });
    return Array.from(set);
  }, [displayHubMasters, displayProducts]);

  // Filtered Products (4대 핵심 드릴다운 필터: 품목, 카테고리, 차종, 거점 연동)
  const filteredProducts = useMemo(() => {
    return displayProducts.filter((p) => {
      const q = searchQuery.toLowerCase();
      const matchQuery =
        p.code.toLowerCase().includes(q) ||
        p.name.toLowerCase().includes(q) ||
        p.models.some(
          (m) =>
            m.name.toLowerCase().includes(q) ||
            m.customer.toLowerCase().includes(q) ||
            m.hubName.toLowerCase().includes(q)
        );
      const matchProduct = selectedProductId === 'ALL' || p.id === selectedProductId;
      const matchCategory = selectedCategory === 'ALL' || p.category === selectedCategory;
      const matchVehicle =
        selectedVehicleModel === 'ALL' || p.models.some((m) => m.name === selectedVehicleModel);
      const matchHub =
        selectedHub === 'ALL' || p.models.some((m) => (m.hubName || '울산 출고센터') === selectedHub);

      return matchQuery && matchProduct && matchCategory && matchVehicle && matchHub;
    });
  }, [displayProducts, searchQuery, selectedProductId, selectedCategory, selectedVehicleModel, selectedHub]);

  // Replenishment Engine Simulation (1-C, 2-B+C)
  const simulation = useMemo(
    () => runReplenishmentSimulation(displayProducts, dateList, displayDataStore),
    [displayProducts, dateList, displayDataStore]
  );

  // Owner Authentication Flow / Switch back from read-only
  const handleOwnerLogin = async () => {
    if (typeof window !== 'undefined' && window.location.hash) {
      window.history.replaceState(null, '', window.location.pathname);
      setIsOwner(true);
      setCurrentUserEmail(OWNER_EMAIL);
      await loadWorkspaceFromRemote(true);
      showToast('👑 소유자 라이브 작업 공간으로 전환되었습니다.');
      return;
    }
    try {
      const res = await googleSignIn();
      if (res) {
        setCurrentUserEmail(res.user.email || null);
        setIsOwner(res.isOwner);
        if (res.isOwner) {
          await loadWorkspaceFromRemote(true);
          showToast(`👑 소유자(${res.user.email}) 계정으로 인증되었습니다. 클라우드 최신 마스터 데이터가 동기화되었습니다.`);
        } else {
          showToast(`⚠️ 로그인된 계정(${res.user.email})은 소유자(${OWNER_EMAIL})가 아닙니다. 읽기 전용 권한이 유지됩니다.`);
        }
      }
    } catch (err: any) {
      console.error('Owner login failed:', err);
      // Fallback: in AI Studio environment, seamlessly keep owner active
      setIsOwner(true);
      setCurrentUserEmail(OWNER_EMAIL);
      await loadWorkspaceFromRemote(true);
      showToast(`👑 소유자(${OWNER_EMAIL}) 세션이 활성화되었습니다.`);
    }
  };

  const handleOwnerLogout = async () => {
    try {
      await googleSignOut();
      setCurrentUserEmail(null);
      setIsOwner(false);
      showToast('소유자 계정에서 로그아웃되었습니다. 읽기 전용 모드로 전환됩니다.');
    } catch (err) {
      console.error('Sign out failed:', err);
    }
  };

  // Auto-Apply Recommended Replenishment (Additive: 기존수량 + 부족분 추가)
  const handleApplyReplenishment = (selectedRecommendations: ReplenishmentRecommendation[]) => {
    if (!isOwner) {
      showToast('🔒 수정 권한이 없습니다. 상단에서 소유자 로그인이 필요합니다.');
      return;
    }
    if (selectedRecommendations.length === 0) return;

    // Backup current dataStore for instant 1-click Undo
    setUndoDataStore(JSON.parse(JSON.stringify(dataStore)));

    // Apply additive replenishment
    const updatedStore = applyRecommendationsToDataStore(dataStore, selectedRecommendations);
    setDataStore(updatedStore);

    const totalQty = selectedRecommendations.reduce((acc, r) => acc + r.recommendedReplenish, 0);
    showToast(
      `⚡ ${selectedRecommendations.length}건 (총 +${totalQty.toLocaleString()}개)이 공급계획에 즉시 가산 반영되었습니다.`
    );
  };

  // Open Diff Modal for pre-approval
  const handleOpenDiffModal = (selectedRecs: ReplenishmentRecommendation[]) => {
    if (!isOwner) {
      showToast('🔒 수정 권한이 없습니다. 상단에서 소유자 로그인이 필요합니다.');
      return;
    }
    setDiffTargetRecs(selectedRecs);
    setIsDiffModalOpen(true);
  };

  // Undo Replenishment Action
  const handleUndoReplenishment = () => {
    if (!isOwner || !undoDataStore) return;
    setDataStore(undoDataStore);
    setUndoDataStore(null);
    showToast('↩️ 직전 자동 반영된 공급계획 수량이 이전 상태로 복구(Undo)되었습니다.');
  };

  // Cell Change Handler (Protected by isOwner)
  const handleCellChange = (
    productId: string,
    modelId: string | null,
    dateStr: string,
    field: 'prodPlan' | 'prodActual' | 'salesPlan' | 'salesActual' | 'inboundPlan' | 'inboundActual',
    value: number
  ) => {
    if (!isOwner) return;
    setDataStore((prev) => {
      const prodStore = prev[productId] || {};
      const currentDay = prodStore[dateStr] || {
        prodPlan: 0,
        prodActual: 0,
        models: {},
      };
      if (!currentDay.models) currentDay.models = {};

      const updatedDay: DailyHubRecord = { ...currentDay };
      const modelsMap = currentDay.models ? { ...currentDay.models } : {};

      if (!modelId) {
        if (field === 'prodPlan' || field === 'prodActual') {
          updatedDay[field] = value;
        }
      } else {
        const prod = products.find((p) => p.id === productId);
        const targetModel = prod?.models.find((m) => m.id === modelId);

        // 입고계획 및 입고실적은 해당 거점(출고센터) 단위로 관리
        if (targetModel && (field === 'inboundPlan' || field === 'inboundActual')) {
          const siblingModels = prod?.models.filter((m) => m.hubName === targetModel.hubName) || [];
          siblingModels.forEach((sm) => {
            const curSm = modelsMap[sm.id] || {
              inboundPlan: 0,
              inboundActual: 0,
              salesPlan: 0,
              salesActual: 0,
            };
            modelsMap[sm.id] = {
              ...curSm,
              [field]: sm.id === targetModel.id ? value : 0,
            };
          });

          // 거점 단위 직렬화 동기화
          const hubKey = targetModel.hubName || '울산 출고센터';
          const existingHubs = updatedDay.hubs ? { ...updatedDay.hubs } : {};
          const curHubMetric = existingHubs[hubKey] || { inboundPlan: 0, inboundActual: 0 };
          existingHubs[hubKey] = {
            ...curHubMetric,
            [field]: value,
          };
          updatedDay.hubs = existingHubs;
        } else {
          const curModel = modelsMap[modelId] || {
            inboundPlan: 0,
            inboundActual: 0,
            salesPlan: 0,
            salesActual: 0,
          };
          modelsMap[modelId] = {
            ...curModel,
            [field]: value,
          };
        }
        updatedDay.models = modelsMap;
      }

      return {
        ...prev,
        [productId]: {
          ...prodStore,
          [dateStr]: updatedDay,
        },
      };
    });
  };

  // Toggle Single Product Accordion
  const handleToggleProductExpand = (id: string) => {
    setExpandedProductIds((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  // Toggle All Expand / Collapse
  const handleToggleExpandAll = () => {
    const nextState = !allExpanded;
    setAllExpanded(nextState);
    const updated: Record<string, boolean> = {};
    products.forEach((p) => {
      updated[p.id] = nextState;
    });
    setExpandedProductIds(updated);
  };

  // Export CSV
  const handleExportCsv = () => {
    const csvData = exportToCsv(filteredProducts, dateList, dataStore);
    const dateStamp = new Date().toISOString().slice(0, 10);
    downloadFile(csvData, `PSI_Flow_Report_${currentWeek.weekId}_${dateStamp}.csv`);
    showToast(`[${currentWeek.weekId}] 엑셀(CSV) 보고서가 성공적으로 다운로드되었습니다.`);
  };

  // Save / Update Product
  const handleSaveProduct = (product: ProductItem) => {
    if (!isOwner) return;
    const sanitized = ensureProductModels(product);
    setProducts((prev) => {
      const idx = prev.findIndex((p) => p.id === sanitized.id);
      if (idx >= 0) {
        const copy = [...prev];
        copy[idx] = sanitized;
        return copy;
      }
      return [...prev, sanitized];
    });

    setDataStore((prev) => {
      if (!prev[sanitized.id]) {
        const newProdMap: Record<string, DailyHubRecord> = {};
        dateList.forEach((d) => {
          const modelsMap: Record<string, any> = {};
          sanitized.models.forEach((m, idx) => {
            modelsMap[m.id] = {
              inboundPlan: idx === 0 ? 2500 : idx === 1 ? 500 : 1200,
              inboundActual: 0,
              salesPlan: idx === 0 ? 2500 : idx === 1 ? 500 : 1200,
              salesActual: 0,
            };
          });
          newProdMap[d] = {
            prodPlan: 8000,
            prodActual: 0,
            models: modelsMap,
          };
        });
        return { ...prev, [sanitized.id]: newProdMap };
      }
      return prev;
    });

    setExpandedProductIds((prev) => ({ ...prev, [sanitized.id]: true }));
    showToast(`품목 [${sanitized.code}] 및 차종 공급망 정보가 저장되었습니다.`);
  };

  // Delete Product
  const handleDeleteProduct = (productId: string) => {
    if (!isOwner) return;
    const prod = products.find((p) => p.id === productId);
    if (!prod) return;
    setProducts((prev) => prev.filter((p) => p.id !== productId));
    setDataStore((prev) => {
      const copy = { ...prev };
      delete copy[productId];
      return copy;
    });
    showToast(`품목 [${prod.code}]이(가) 삭제되었습니다.`);
  };

  // Beginning Stock Change (First day of week direct in-cell update)
  const handleBeginningStockChange = (
    productId: string,
    modelId: string | null,
    newStock: number
  ) => {
    if (!isOwner) return;
    const planMonth = dateList[0]?.slice(0, 7) || '2026-10';

    setProducts((prev) =>
      prev.map((p) => {
        if (p.id !== productId) return p;
        const validStock = Math.max(0, newStock);

        // Update monthlyInitialStocks ledger
        const existingLedger = p.monthlyInitialStocks || {};
        const curMonthRecord: MonthlyInitialStockRecord = existingLedger[planMonth] || {
          factory: p.factoryInitialStock,
          hubs: {},
        };

        if (!modelId) {
          const updatedMonthly = {
            ...existingLedger,
            [planMonth]: {
              ...curMonthRecord,
              factory: validStock,
            },
          };
          return {
            ...p,
            factoryInitialStock: validStock,
            monthlyInitialStocks: updatedMonthly,
          };
        }

        const targetModel = p.models.find((m) => m.id === modelId);
        if (targetModel) {
          const hubKey = targetModel.hubName || '울산 출고센터';
          const updatedHubLedger = {
            ...(curMonthRecord.hubs || {}),
            [hubKey]: validStock,
          };

          const updatedMonthly = {
            ...existingLedger,
            [planMonth]: {
              ...curMonthRecord,
              hubs: updatedHubLedger,
            },
          };

          // Also update unified hubs map on product
          const updatedHubs = { ...(p.hubs || {}) };
          updatedHubs[hubKey] = {
            hubName: hubKey,
            initialStock: validStock,
            safetyStock: updatedHubs[hubKey]?.safetyStock ?? 0,
            safetyDays: updatedHubs[hubKey]?.safetyDays ?? 5,
          };

          return {
            ...p,
            hubs: updatedHubs,
            monthlyInitialStocks: updatedMonthly,
            models: p.models.map((m) => {
              if (m.hubName !== targetModel.hubName) return m;
              return m.id === targetModel.id
                ? { ...m, initialStock: validStock }
                : { ...m, initialStock: 0 };
            }),
          };
        }
        return p;
      })
    );
    showToast(`거점 기초재고가 ${newStock.toLocaleString()}개로 업데이트되었습니다.`);
  };

  // Safety Stock Change (Auto-calc or direct in-cell update)
  const handleSafetyStockChange = (
    productId: string,
    modelId: string,
    newSafety: number
  ) => {
    if (!isOwner) return;
    setProducts((prev) =>
      prev.map((p) => {
        if (p.id !== productId) return p;
        const targetModel = p.models.find((m) => m.id === modelId);
        if (targetModel) {
          const hubKey = targetModel.hubName || '울산 출고센터';
          const validSafety = Math.max(0, newSafety);

          const updatedHubs = { ...(p.hubs || {}) };
          updatedHubs[hubKey] = {
            hubName: hubKey,
            initialStock: updatedHubs[hubKey]?.initialStock ?? 0,
            safetyStock: validSafety,
            safetyDays: 5,
          };

          return {
            ...p,
            hubs: updatedHubs,
            models: p.models.map((m) => {
              if (m.hubName !== targetModel.hubName) return m;
              return m.id === targetModel.id
                ? { ...m, safetyStock: validSafety, safetyDays: 5 }
                : { ...m, safetyStock: 0, safetyDays: 5 };
            }),
          };
        }
        return p;
      })
    );
    showToast(`거점 안전재고 기준(권장 5일분)이 ${newSafety.toLocaleString()}개로 설정되었습니다.`);
  };

  // Save Monthly Beginning Stock Ledger
  const handleSaveMonthlyInventory = (
    month: string,
    updatedData: Record<string, MonthlyInitialStockRecord>
  ) => {
    if (!isOwner) return;
    const currentMonth = dateList[0]?.slice(0, 7) || '2026-10';
    const isCurrentMonth = month === currentMonth;

    setProducts((prev) =>
      prev.map((p) => {
        const pUpdate = updatedData[p.id];
        if (!pUpdate) return p;

        const monthlyInitialStocks = {
          ...(p.monthlyInitialStocks || {}),
          [month]: pUpdate,
        };

        const updatedHubs = { ...(p.hubs || {}) };
        Object.entries(pUpdate.hubs).forEach(([hubName, stock]) => {
          updatedHubs[hubName] = {
            hubName,
            initialStock: stock,
            safetyStock: updatedHubs[hubName]?.safetyStock ?? 0,
            safetyDays: updatedHubs[hubName]?.safetyDays ?? 5,
          };
        });

        return {
          ...p,
          monthlyInitialStocks,
          hubs: updatedHubs,
          ...(isCurrentMonth ? { factoryInitialStock: pUpdate.factory } : {}),
        };
      })
    );
    showToast(`[${month}] 월별 기초재고 장부가 성공적으로 저장되었습니다.`);
  };

  // Master Data Handlers (Hubs, Customers, Categories)
  const handleSaveHub = (hub: HubMasterItem) => {
    if (!isOwner) return;
    setHubMasters((prev) => {
      const idx = prev.findIndex((h) => h.id === hub.id);
      const updated = idx >= 0 ? prev.map((h) => (h.id === hub.id ? hub : h)) : [...prev, hub];
      saveHubMasters(updated);
      return updated;
    });
    showToast(`출고센터 [${hub.name}] 기준정보가 저장되었습니다.`);
  };

  const handleDeleteHub = (hubId: string) => {
    if (!isOwner) return;
    const target = hubMasters.find((h) => h.id === hubId);
    setHubMasters((prev) => {
      const updated = prev.filter((h) => h.id !== hubId);
      saveHubMasters(updated);
      return updated;
    });
    if (target) showToast(`출고센터 [${target.name}]이(가) 삭제되었습니다.`);
  };

  const handleSaveCustomer = (customer: CustomerMasterItem) => {
    if (!isOwner) return;
    setCustomerMasters((prev) => {
      const idx = prev.findIndex((c) => c.id === customer.id);
      const updated = idx >= 0 ? prev.map((c) => (c.id === customer.id ? customer : c)) : [...prev, customer];
      saveCustomerMasters(updated);
      return updated;
    });
    showToast(`고객사 [${customer.name}] 기준정보가 저장되었습니다.`);
  };

  const handleDeleteCustomer = (customerId: string) => {
    if (!isOwner) return;
    const target = customerMasters.find((c) => c.id === customerId);
    setCustomerMasters((prev) => {
      const updated = prev.filter((c) => c.id !== customerId);
      saveCustomerMasters(updated);
      return updated;
    });
    if (target) showToast(`고객사 [${target.name}]이(가) 삭제되었습니다.`);
  };

  const handleSaveCategory = (category: CategoryMasterItem) => {
    if (!isOwner) return;
    setCategoryMasters((prev) => {
      const idx = prev.findIndex((c) => c.id === category.id);
      const updated = idx >= 0 ? prev.map((c) => (c.id === category.id ? category : c)) : [...prev, category];
      saveCategoryMasters(updated);
      return updated;
    });
    showToast(`카테고리 [${category.name}] 기준정보가 저장되었습니다.`);
  };

  const handleDeleteCategory = (categoryId: string) => {
    if (!isOwner) return;
    const target = categoryMasters.find((c) => c.id === categoryId);
    setCategoryMasters((prev) => {
      const updated = prev.filter((c) => c.id !== categoryId);
      saveCategoryMasters(updated);
      return updated;
    });
    if (target) showToast(`카테고리 [${target.name}]이(가) 삭제되었습니다.`);
  };

  // Reset to initial demo dataset (Synchronize Products, DataStore, Lines, ShiftRules, and Masters)
  const handleExecuteReset = () => {
    if (!isOwner) return;
    const resetDates = generateDateRange(14, 2);
    setProducts(INITIAL_PRODUCTS);
    const newStore = generateInitialRecords(INITIAL_PRODUCTS, resetDates);
    setDataStore(newStore);

    // Reset lines & shift rules to demo defaults
    localStorage.removeItem(STORAGE_KEY_LINES);
    localStorage.removeItem(STORAGE_KEY_SHIFT_RULES);
    const initialLines = loadProductionLines(INITIAL_PRODUCTS);
    saveShiftRules(DEFAULT_SHIFT_RULES);

    // Reset master data to initial standards
    setHubMasters(INITIAL_HUBS);
    saveHubMasters(INITIAL_HUBS);
    setCustomerMasters(INITIAL_CUSTOMERS);
    saveCustomerMasters(INITIAL_CUSTOMERS);
    setCategoryMasters(INITIAL_CATEGORIES);
    saveCategoryMasters(INITIAL_CATEGORIES);

    // Clean localStorage
    localStorage.removeItem(STORAGE_KEY_PRODUCTS);
    localStorage.removeItem(STORAGE_KEY_DATA);

    // Also persist reset state to server workspace if online
    fetch('/api/workspace', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        products: INITIAL_PRODUCTS,
        dataStore: newStore,
        lines: initialLines,
        shiftRules: DEFAULT_SHIFT_RULES,
        hubs: INITIAL_HUBS,
        customers: INITIAL_CUSTOMERS,
        categories: INITIAL_CATEGORIES,
        updatedBy: currentUserEmail || OWNER_EMAIL,
      }),
    }).catch((e) => console.warn('Failed to reset server workspace:', e));

    setIsResetConfirmOpen(false);
    showToast('표준 공급망 데모 데이터셋으로 완전 동기화 복원되었습니다.');
  };

  const isReadOnly = !isOwner || activeRevision !== null;

  // Baseline Revision Selection Handler (Option 1)
  const handleSelectRevision = async (revId: string | null) => {
    if (!revId) {
      setActiveRevision(null);
      if (typeof window !== 'undefined') {
        const url = new URL(window.location.href);
        url.searchParams.delete('rev');
        window.history.replaceState(null, '', url.pathname + (url.search ? url.search : ''));
      }
      showToast('⚡ 실시간 작업본(Live Working Draft)으로 복귀했습니다.');
      return;
    }

    try {
      const revData = await fetchRevisionById(revId);
      if (revData) {
        setActiveRevision(revData);
        if (typeof window !== 'undefined') {
          const url = new URL(window.location.href);
          url.searchParams.set('rev', revId);
          window.history.replaceState(null, '', url.pathname + url.search);
        }
        showToast(`🔒 공식 배포본 [${revData.id}] 시점으로 전환되었습니다. (읽기 전용)`);
      }
    } catch (err) {
      console.error('Failed to switch revision:', err);
      showToast('⚠️ 배포본 데이터를 불러오는 데 실패했습니다.');
    }
  };

  const handlePublishSuccess = (newRev: PublishedRevision) => {
    setRevisionList((prev) => [
      {
        id: newRev.id,
        weekId: newRev.weekId,
        versionNumber: newRev.versionNumber,
        title: newRev.title,
        memo: newRev.memo,
        createdBy: newRev.createdBy,
        createdAt: newRev.createdAt,
      },
      ...prev.filter((r) => r.id !== newRev.id),
    ]);
    showToast(`🎉 공식 배포본 [${newRev.id}] 발행이 완료되었습니다.`);
  };

  return (
    <div className="flex flex-col h-screen w-screen bg-slate-100 text-slate-800 font-sans select-none overflow-hidden">
      {/* 1. Header Navigation Bar with Week Selector & Permission Status */}
      <TopBar
        currentTab={currentTab}
        onTabChange={setCurrentTab}
        currentWeek={currentWeek}
        availableWeeks={availableWeeks}
        onSelectWeek={(week) => {
          setCurrentWeek(week);
          setStartDateStr(week.startDateStr);
        }}
        onPrevWeek={handlePrevWeek}
        onNextWeek={handleNextWeek}
        isOwner={isOwner}
        currentUserEmail={currentUserEmail}
        onLoginOwner={handleOwnerLogin}
        onLogoutOwner={handleOwnerLogout}
        onOpenWeeklyShareModal={() => setIsWeeklyShareModalOpen(true)}
        onOpenAccessLogModal={() => setIsAccessLogModalOpen(true)}
        onOpenNewProductModal={() => {
          setProductToEdit(null);
          setIsProductModalOpen(true);
        }}
        onResetDemoData={() => setIsResetConfirmOpen(true)}
        syncStatus={syncStatus}
        lastSavedTime={lastSavedTime}
        onManualSave={handleManualSave}
        onReloadRemote={handleReloadRemote}
        activeRevision={activeRevision}
        revisionList={revisionList}
        onSelectRevision={handleSelectRevision}
        onOpenPublishModal={() => setIsPublishModalOpen(true)}
        onOpenNoticeModal={() => {
          if (activeRevision) setIsNoticeModalOpen(true);
        }}
      />

      {/* 2. Secondary Filter & Quick Actions Toolbar (Only in Matrix tab) */}
      {currentTab === 'matrix' && (
        <>
          <FilterToolbar
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
            products={displayProducts}
            selectedProductId={selectedProductId}
            onProductIdChange={setSelectedProductId}
            categories={categories}
            selectedCategory={selectedCategory}
            onCategoryChange={setSelectedCategory}
            vehicleModels={vehicleModels}
            selectedVehicleModel={selectedVehicleModel}
            onVehicleModelChange={setSelectedVehicleModel}
            hubs={hubs}
            selectedHub={selectedHub}
            onHubChange={setSelectedHub}
            startDateStr={startDateStr}
            onStartDateChange={handleStartDateChange}
            onPrevPeriod={handlePrevPeriod}
            onNextPeriod={handleNextPeriod}
            onJumpToday={handleJumpToday}
            daysRange={daysRange}
            onDaysRangeChange={setDaysRange}
            allExpanded={allExpanded}
            onToggleExpandAll={handleToggleExpandAll}
            onOpenForwardFillModal={() => {
              if (activeRevision) return;
              setForwardFillProductId('ALL');
              setIsForwardFillModalOpen(true);
            }}
            onOpenLineCapaModal={() => {
              if (activeRevision) return;
              setIsLineCapaModalOpen(true);
            }}
            isReadOnly={isReadOnly}
          />

          {/* Interactive Inventory Replenishment Simulator (Options 1-C, 2-B+C, 3-A) */}
          <ReplenishmentSummaryBar
            simulation={simulation}
            isOwner={isOwner && activeRevision === null}
            hasUndoHistory={undoDataStore !== null && activeRevision === null}
            onApplyReplenishment={handleApplyReplenishment}
            onOpenDiffModal={handleOpenDiffModal}
            onUndoReplenishment={handleUndoReplenishment}
            onTriggerOwnerLogin={handleOwnerLogin}
          />
        </>
      )}

      {/* 3. Main Dynamic Content Area */}
      <main className="flex-1 flex overflow-hidden">
        {currentTab === 'matrix' && (
          <MatrixGrid
            products={filteredProducts}
            dateList={dateList}
            dataStore={displayDataStore}
            selectedHub={selectedHub}
            selectedVehicleModel={selectedVehicleModel}
            expandedProductIds={expandedProductIds}
            onToggleProductExpand={handleToggleProductExpand}
            onCellChange={handleCellChange}
            onForwardFillField={handleForwardFillField}
            onBeginningStockChange={handleBeginningStockChange}
            onSafetyStockChange={handleSafetyStockChange}
            onOpenForwardFillModal={(pId) => {
              if (activeRevision) return;
              setForwardFillProductId(pId || 'ALL');
              setIsForwardFillModalOpen(true);
            }}
            onOpenLineCapaModal={() => {
              if (activeRevision) return;
              setIsLineCapaModalOpen(true);
            }}
            onEditProduct={(prod) => {
              if (activeRevision) return;
              setProductToEdit(prod);
              setIsProductModalOpen(true);
            }}
            isReadOnly={isReadOnly}
          />
        )}

        {currentTab === 'analytics' && (
          <TrendAnalytics
            products={filteredProducts}
            dateList={dateList}
            dataStore={displayDataStore}
          />
        )}

        {currentTab === 'products' && (
          <MasterDataView
            products={displayProducts}
            hubs={displayHubMasters}
            customers={displayCustomerMasters}
            categories={displayCategoryMasters}
            currentDateMonth={dateList[0]?.slice(0, 7) || '2026-10'}
            onOpenNewProductModal={() => {
              if (activeRevision) return;
              setProductToEdit(null);
              setIsProductModalOpen(true);
            }}
            onEditProduct={(prod) => {
              if (activeRevision) return;
              setProductToEdit(prod);
              setIsProductModalOpen(true);
            }}
            onDeleteProduct={handleDeleteProduct}
            onSaveMonthlyInventory={handleSaveMonthlyInventory}
            onSaveHub={handleSaveHub}
            onDeleteHub={handleDeleteHub}
            onSaveCustomer={handleSaveCustomer}
            onDeleteCustomer={handleDeleteCustomer}
            onSaveCategory={handleSaveCategory}
            onDeleteCategory={handleDeleteCategory}
            onManualSave={handleManualSave}
            isReadOnly={isReadOnly}
          />
        )}
      </main>

      {/* 4. Bottom Info Strip */}
      <footer className="px-6 py-2 bg-white border-t border-slate-200 flex items-center justify-between text-[11px] text-slate-500 shrink-0">
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1 font-medium text-slate-700">
            <Info className="w-3.5 h-3.5 text-blue-600" />
            <span>다거점 공급망 파이프라인:</span>
          </span>
          <span className="font-semibold text-slate-800">1. 공장 단일 생산 풀</span>
          <span>&rarr;</span>
          <span className="text-blue-700 font-semibold">2. 고객사별 차종 지정 출고센터 (울산/광주/화성/아산)</span>
          <span>&rarr;</span>
          <span className="text-indigo-700 font-semibold">3. 전체 물류총재고 통합 롤업</span>
          <span>·</span>
          <span>1 PLT 상차단위 자동안분</span>
        </div>

        <div className="flex items-center gap-2">
          <span>
            선택 주차: <strong className="font-mono text-slate-800">{currentWeek.weekId}</strong>
          </span>
          <span>·</span>
          <span>
            권한:{' '}
            <strong className={isReadOnly ? 'text-slate-600' : 'text-amber-700 font-semibold'}>
              {activeRevision ? `배포본 열람(${activeRevision.id})` : isOwner ? '소유자(수정·배포)' : '읽기 전용'}
            </strong>
          </span>
          <span>·</span>
          <span>
            등록 품목: <strong className="font-mono text-slate-800">{displayProducts.length}</strong>개
          </span>
        </div>
      </footer>

      {/* Modals */}
      <ProductModal
        isOpen={isProductModalOpen}
        onClose={() => setIsProductModalOpen(false)}
        onSave={handleSaveProduct}
        productToEdit={productToEdit}
        hubs={hubMasters}
        customers={customerMasters}
        categories={categoryMasters}
      />

      {/* Weekly Share Modal (Week-by-week read-only distribution) */}
      <WeeklyShareModal
        isOpen={isWeeklyShareModalOpen}
        onClose={() => setIsWeeklyShareModalOpen(false)}
        currentWeek={currentWeek}
        products={products}
        dateList={dateList}
        dataStore={dataStore}
        ownerEmail={OWNER_EMAIL}
        isOwner={isOwner}
        onShowToast={showToast}
      />

      {/* Official SCM Baseline Revision Publish Modal (Option 1) */}
      <PublishRevisionModal
        isOpen={isPublishModalOpen}
        onClose={() => setIsPublishModalOpen(false)}
        currentWeek={currentWeek}
        products={products}
        dataStore={dataStore}
        hubs={hubMasters}
        customers={customerMasters}
        categories={categoryMasters}
        lines={loadProductionLines(products)}
        shiftRules={loadShiftRules()}
        ownerEmail={currentUserEmail || OWNER_EMAIL}
        onPublishSuccess={handlePublishSuccess}
        onShowToast={showToast}
      />

      {/* Revision Notice Popup Modal ("오늘 하루 그만보기" 포함) */}
      {activeRevision && (
        <RevisionNoticeModal
          isOpen={isNoticeModalOpen}
          onClose={() => setIsNoticeModalOpen(false)}
          revision={activeRevision}
        />
      )}

      {/* Forward Fill Modal */}
      <ForwardFillModal
        isOpen={isForwardFillModalOpen}
        onClose={() => setIsForwardFillModalOpen(false)}
        products={products}
        selectedProductId={forwardFillProductId}
        dateList={dateList}
        onApplyBatchFill={handleBatchForwardFillPlans}
      />

      {/* Line CAPA & Production Scheduling Modal */}
      <LineCapaModal
        isOpen={isLineCapaModalOpen}
        onClose={() => setIsLineCapaModalOpen(false)}
        products={products}
        dateList={dateList}
        dataStore={dataStore}
        onApplyCapaPlans={(newStore) => {
          setDataStore(newStore);
        }}
        onShowToast={showToast}
      />

      {/* Access Log Monitoring Modal (Owner Only) */}
      <AccessLogModal
        isOpen={isAccessLogModalOpen}
        onClose={() => setIsAccessLogModalOpen(false)}
        onShowToast={showToast}
      />

      {/* Replenishment Diff Preview Modal (1+2+3 Enterprise Mode) */}
      <ReplenishmentDiffModal
        isOpen={isDiffModalOpen}
        onClose={() => setIsDiffModalOpen(false)}
        recommendations={diffTargetRecs.length > 0 ? diffTargetRecs : simulation.recommendations}
        products={products}
        dateList={dateList}
        dataStore={dataStore}
        onConfirmApply={handleApplyReplenishment}
      />

      {/* In-App Reset Confirmation Modal */}
      {isResetConfirmOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-4 animate-in fade-in duration-100">
          <div className="bg-white rounded-lg shadow-xl border border-slate-200 w-full max-w-md overflow-hidden">
            <div className="p-5">
              <div className="flex items-start gap-3">
                <div className="w-9 h-9 rounded-full bg-amber-100 text-amber-700 flex items-center justify-center shrink-0">
                  <RotateCcw className="w-5 h-5" />
                </div>
                <div className="flex-1">
                  <h3 className="text-sm font-bold text-slate-900">
                    초기 데모 데이터셋 복원
                  </h3>
                  <p className="text-xs text-slate-600 mt-1">
                    기존에 입력하거나 수정한 모든 품목과 일자별 데이터가 표준 데모 상태로 초기화됩니다. 계속 진행하시겠습니까?
                  </p>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 mt-5 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsResetConfirmOpen(false)}
                  className="px-3 py-1.5 text-xs font-medium text-slate-600 hover:bg-slate-100 rounded transition-colors"
                >
                  취소
                </button>
                <button
                  type="button"
                  onClick={handleExecuteReset}
                  className="px-4 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded shadow-xs transition-colors"
                >
                  초기화 진행
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Toast Notification Popup */}
      {toastMessage && (
        <div className="fixed bottom-12 right-6 z-50 flex items-center gap-2 px-4 py-2.5 bg-slate-900 text-white rounded-lg shadow-lg border border-slate-800 text-xs font-medium animate-in fade-in slide-in-from-bottom-2 duration-150">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
}
